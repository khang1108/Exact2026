"""EXACT application package."""
