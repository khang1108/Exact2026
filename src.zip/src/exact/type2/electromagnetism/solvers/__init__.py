"""Deterministic electromagnetism sub-solvers."""
