from __future__ import annotations

import math

from exact.type2.schemas import Formula
from exact.type2.solving.units import ureg


def _q(known: dict[str, object], name: str):
    return known[name]


def _angle_radians(known: dict[str, object], name: str = "angle") -> float:
    return _q(known, name).to("radian").magnitude


def _charge_sign(quantity) -> int:
    return 1 if quantity.magnitude >= 0 else -1


def _cos_from_sides(side_1, side_2, opposite_side) -> float:
    a = side_1.to("meter").magnitude
    b = side_2.to("meter").magnitude
    c = opposite_side.to("meter").magnitude
    denominator = 2 * a * b
    if denominator == 0:
        raise ValueError("Triangle side length must be non-zero.")
    cosine = (a * a + b * b - c * c) / denominator
    return max(-1.0, min(1.0, cosine))


def _net_force_on_third_charge_by_triangle_sides(known: dict[str, object]):
    q1 = _q(known, "charge")
    q2 = _q(known, "charge_2")
    q3 = _q(known, "charge_3")
    r13 = _q(known, "length")
    r23 = _q(known, "length_2")
    r12 = _q(known, "length_3")

    f13 = K_COULOMB * abs(q1 * q3) / (r13 ** 2)
    f23 = K_COULOMB * abs(q2 * q3) / (r23 ** 2)
    cos_source_angle = _cos_from_sides(r13, r23, r12)
    direction_factor = _charge_sign(q1 * q3) * _charge_sign(q2 * q3)
    return (f13 ** 2 + f23 ** 2 + 2 * f13 * f23 * direction_factor * cos_source_angle) ** 0.5


def _net_force_on_a_in_right_triangle(known: dict[str, object]):
    qa = _q(known, "charge")
    qb = _q(known, "charge_2")
    qc = _q(known, "charge_3")
    ab = _q(known, "length")
    hypotenuse_bc = _q(known, "length_2")
    ac = (hypotenuse_bc ** 2 - ab ** 2) ** 0.5
    force_ab = K_COULOMB * abs(qa * qb) / (ab ** 2)
    force_ac = K_COULOMB * abs(qa * qc) / (ac ** 2)
    return (force_ab ** 2 + force_ac ** 2) ** 0.5


def _pythagorean_leg(known: dict[str, object]):
    hypotenuse = _q(known, "length")
    leg = _q(known, "length_2")
    return (hypotenuse ** 2 - leg ** 2) ** 0.5


def _deflection_angle_in_uniform_field(known: dict[str, object]):
    charge = abs(_q(known, "charge"))
    field = _q(known, "electric_field")
    mass = _q(known, "mass")
    gravity = _q(known, "acceleration")
    return math.atan((charge * field) / (mass * gravity)) * ureg.radian


def _angle_between_forces_from_resultant(known: dict[str, object]):
    f1 = _q(known, "force").to("N").magnitude
    f2 = _q(known, "force_2").to("N").magnitude
    resultant = _q(known, "resultant_force").to("N").magnitude
    denominator = 2 * f1 * f2
    if denominator == 0:
        raise ValueError("Force magnitudes must be non-zero to solve for the included angle.")
    cosine = (resultant * resultant - f1 * f1 - f2 * f2) / denominator
    cosine = max(-1.0, min(1.0, cosine))
    return math.acos(cosine) * ureg.radian

K_COULOMB = 8.9875517923e9 * ureg.newton * (ureg.meter ** 2) / (ureg.coulomb ** 2)
EPSILON_0 = 8.8541878128e-12 * ureg.farad / ureg.meter
MU_0 = 4 * math.pi * 1e-7 * ureg.newton / (ureg.ampere ** 2)
C_LIGHT = 299792458 * ureg.meter / ureg.second
STEFAN_BOLTZMANN = 5.670374419e-8 * ureg.watt / (ureg.meter ** 2 * ureg.kelvin ** 4)


FORMULAS: tuple[Formula, ...] = (
    Formula(
        id="ohm_voltage",
        domain="circuits",
        subfield="dc_circuits",
        target="voltage",
        required=("current", "resistance"),
        output_unit="V",
        expression="U = I * R",
        explanation_template="Ohm's law gives voltage as U = I * R.",
        keywords=("voltage", "current", "resistance", "resistor", "ohm"),
        variables={"U": "voltage", "I": "current", "R": "resistance"},
        conditions=("Ohmic resistor or equivalent DC resistance.",),
        common_mistakes=("Do not multiply voltage by resistance when solving for current.",),
        solve=lambda k: _q(k, "current") * _q(k, "resistance"),
    ),
    Formula(
        id="ohm_current",
        domain="circuits",
        subfield="dc_circuits",
        target="current",
        required=("voltage", "resistance"),
        output_unit="A",
        expression="I = U / R",
        explanation_template="Ohm's law gives current as I = U / R.",
        keywords=("current", "voltage", "resistance", "resistor", "ohm"),
        variables={"I": "current", "U": "voltage", "R": "resistance"},
        conditions=("Ohmic resistor or equivalent DC resistance.",),
        common_mistakes=("Current is voltage divided by resistance, not resistance divided by voltage.",),
        solve=lambda k: _q(k, "voltage") / _q(k, "resistance"),
    ),
    Formula(
        id="current_from_voltage_impedance",
        domain="circuits",
        subfield="ac_circuits",
        target="current",
        required=("voltage", "impedance"),
        output_unit="A",
        expression="I = U / Z",
        explanation_template="For an AC circuit, RMS current is RMS voltage divided by total impedance: I = U/Z.",
        keywords=("rms current", "effective current", "voltage", "impedance", "rlc"),
        variables={"I": "current", "U": "voltage", "Z": "impedance"},
        conditions=("Voltage and impedance are RMS/effective values for the same circuit.",),
        common_mistakes=("Use total impedance, not only resistance, unless the circuit is at resonance.",),
        solve=lambda k: _q(k, "voltage") / _q(k, "impedance"),
    ),
    Formula(
        id="ohm_resistance",
        domain="circuits",
        subfield="dc_circuits",
        target="resistance",
        required=("voltage", "current"),
        output_unit="ohm",
        expression="R = U / I",
        explanation_template="Ohm's law gives resistance as R = U / I.",
        keywords=("resistance", "voltage", "current", "resistor", "ohm"),
        variables={"R": "resistance", "U": "voltage", "I": "current"},
        conditions=("Ohmic resistor or equivalent DC resistance.",),
        common_mistakes=("Resistance is voltage divided by current.",),
        solve=lambda k: _q(k, "voltage") / _q(k, "current"),
    ),
    Formula(
        id="impedance_from_voltage_current",
        domain="circuits",
        subfield="ac_circuits",
        target="impedance",
        required=("voltage", "current"),
        output_unit="ohm",
        expression="Z = U / I",
        explanation_template="Total impedance is RMS voltage divided by RMS current: Z = U/I.",
        keywords=("total impedance", "voltage", "current", "rlc", "ac"),
        variables={"Z": "impedance", "U": "voltage", "I": "current"},
        conditions=("Voltage and current are RMS/effective values for the same circuit.",),
        common_mistakes=("Use impedance Z, not only resistance R, for the whole AC circuit.",),
        solve=lambda k: _q(k, "voltage") / _q(k, "current"),
    ),
    Formula(
        id="power_voltage_current",
        domain="circuits",
        subfield="dc_power",
        target="power",
        required=("voltage", "current"),
        output_unit="W",
        expression="P = U * I",
        explanation_template="Electrical power is P = U * I.",
        keywords=("power", "voltage", "current", "circuit"),
        variables={"P": "power", "U": "voltage", "I": "current"},
        conditions=("Voltage and current refer to the same component or circuit branch.",),
        common_mistakes=("Do not combine voltage and current from different components.",),
        solve=lambda k: _q(k, "voltage") * _q(k, "current"),
    ),
    Formula(
        id="power_current_resistance",
        domain="circuits",
        subfield="dc_power",
        target="power",
        required=("current", "resistance"),
        output_unit="W",
        expression="P = I^2 * R",
        explanation_template="Using Ohm's law, power can be computed as P = I^2 * R.",
        keywords=("power", "current", "resistance", "resistor"),
        variables={"P": "power", "I": "current", "R": "resistance"},
        conditions=("Current and resistance refer to the same resistor.",),
        common_mistakes=("Square the current, not the resistance.",),
        solve=lambda k: (_q(k, "current") ** 2) * _q(k, "resistance"),
    ),
    Formula(
        id="power_voltage_resistance",
        domain="circuits",
        subfield="dc_power",
        target="power",
        required=("voltage", "resistance"),
        output_unit="W",
        expression="P = U^2 / R",
        explanation_template="Using Ohm's law, power can be computed as P = U^2 / R.",
        keywords=("power", "voltage", "resistance", "resistor"),
        variables={"P": "power", "U": "voltage", "R": "resistance"},
        conditions=("Voltage and resistance refer to the same resistor.",),
        common_mistakes=("Square the voltage before dividing by resistance.",),
        solve=lambda k: (_q(k, "voltage") ** 2) / _q(k, "resistance"),
    ),
    Formula(
        id="ac_power_from_voltage_impedance_resistance",
        domain="circuits",
        subfield="ac_circuits",
        target="power",
        required=("voltage", "impedance", "resistance"),
        output_unit="W",
        expression="P = U^2 * R / Z^2",
        explanation_template="In a series AC circuit, real power is P = I^2R with I = U/Z, so P = U^2R/Z^2.",
        keywords=("power consumed", "voltage", "impedance", "resistance", "rlc"),
        variables={"P": "power", "U": "voltage", "Z": "impedance", "R": "resistance"},
        conditions=("RMS voltage, total impedance, and resistance refer to the same AC circuit.",),
        common_mistakes=("Use only the resistive part for real power dissipation.",),
        solve=lambda k: (_q(k, "voltage") ** 2) * _q(k, "resistance") / (_q(k, "impedance") ** 2),
    ),
    Formula(
        id="power_factor_from_resistance_impedance",
        domain="circuits",
        subfield="ac_circuits",
        target="power_factor",
        required=("resistance", "impedance"),
        output_unit="dimensionless",
        expression="cos(phi) = R / Z",
        explanation_template="For a series RLC circuit, the power factor is cos(phi) = R/Z.",
        keywords=("power factor", "cos", "resistance", "impedance", "rlc"),
        variables={"cos_phi": "power_factor", "R": "resistance", "Z": "impedance"},
        conditions=("R and Z refer to the same series circuit.",),
        common_mistakes=("Power factor is dimensionless.",),
        solve=lambda k: _q(k, "resistance") / _q(k, "impedance"),
    ),
    Formula(
        id="voltage_from_power_current",
        domain="circuits",
        subfield="dc_power",
        target="voltage",
        required=("power", "current"),
        output_unit="V",
        expression="U = P / I",
        explanation_template="From P = U * I, voltage is U = P / I.",
        keywords=("voltage", "power", "current", "electrical power"),
        variables={"U": "voltage", "P": "power", "I": "current"},
        conditions=("Power and current refer to the same component or circuit branch.",),
        common_mistakes=("Divide power by current to get voltage.",),
        solve=lambda k: _q(k, "power") / _q(k, "current"),
    ),
    Formula(
        id="current_from_power_voltage",
        domain="circuits",
        subfield="dc_power",
        target="current",
        required=("power", "voltage"),
        output_unit="A",
        expression="I = P / U",
        explanation_template="From P = U * I, current is I = P / U.",
        keywords=("current", "power", "voltage", "electrical power"),
        variables={"I": "current", "P": "power", "U": "voltage"},
        conditions=("Power and voltage refer to the same component or circuit branch.",),
        common_mistakes=("Divide power by voltage to get current.",),
        solve=lambda k: _q(k, "power") / _q(k, "voltage"),
    ),
    Formula(
        id="resistance_from_power_current",
        domain="circuits",
        subfield="dc_power",
        target="resistance",
        required=("power", "current"),
        output_unit="ohm",
        expression="R = P / I^2",
        explanation_template="From P = I^2R, resistance is R = P/I^2.",
        keywords=("resistance", "power", "current", "resistor"),
        variables={"R": "resistance", "P": "power", "I": "current"},
        conditions=("Power and current refer to the same resistor.",),
        common_mistakes=("Square the current before dividing.",),
        solve=lambda k: _q(k, "power") / (_q(k, "current") ** 2),
    ),
    Formula(
        id="current_from_power_resistance",
        domain="circuits",
        subfield="dc_power",
        target="current",
        required=("power", "resistance"),
        output_unit="A",
        expression="I = sqrt(P / R)",
        explanation_template="From P = I^2R, current is I = sqrt(P/R).",
        keywords=("current", "power", "resistance", "resistor"),
        variables={"I": "current", "P": "power", "R": "resistance"},
        conditions=("Power and resistance refer to the same resistor.",),
        common_mistakes=("Take the square root after dividing P by R.",),
        solve=lambda k: (_q(k, "power") / _q(k, "resistance")) ** 0.5,
    ),
    Formula(
        id="voltage_from_power_resistance",
        domain="circuits",
        subfield="dc_power",
        target="voltage",
        required=("power", "resistance"),
        output_unit="V",
        expression="U = sqrt(P * R)",
        explanation_template="From P = U^2/R, voltage is U = sqrt(P*R).",
        keywords=("voltage", "power", "resistance", "resistor"),
        variables={"U": "voltage", "P": "power", "R": "resistance"},
        conditions=("Power and resistance refer to the same resistor.",),
        common_mistakes=("Take the square root after multiplying P by R.",),
        solve=lambda k: (_q(k, "power") * _q(k, "resistance")) ** 0.5,
    ),
    Formula(
        id="resistance_from_voltage_power",
        domain="circuits",
        subfield="dc_power",
        target="resistance",
        required=("voltage", "power"),
        output_unit="ohm",
        expression="R = U^2 / P",
        explanation_template="From P = U^2/R, resistance is R = U^2/P.",
        keywords=("resistance", "voltage", "power", "resistor"),
        variables={"R": "resistance", "U": "voltage", "P": "power"},
        conditions=("Voltage and power refer to the same resistor.",),
        common_mistakes=("Square the voltage before dividing by power.",),
        solve=lambda k: (_q(k, "voltage") ** 2) / _q(k, "power"),
    ),
    Formula(
        id="energy_from_power_time",
        domain="circuits",
        subfield="dc_power",
        target="energy",
        required=("power", "time"),
        output_unit="J",
        expression="E = P * t",
        explanation_template="Energy transferred at constant power is E = P * t.",
        keywords=("energy", "power", "time", "electrical energy"),
        variables={"E": "energy", "P": "power", "t": "time"},
        conditions=("Power is constant over the time interval.",),
        common_mistakes=("Use seconds for time when power is in watts.",),
        solve=lambda k: _q(k, "power") * _q(k, "time"),
    ),
    Formula(
        id="power_from_energy_time",
        domain="circuits",
        subfield="dc_power",
        target="power",
        required=("energy", "time"),
        output_unit="W",
        expression="P = E / t",
        explanation_template="Average power is energy transferred per unit time: P = E/t.",
        keywords=("power", "energy", "time", "rate"),
        variables={"P": "power", "E": "energy", "t": "time"},
        conditions=("Average power over the given time interval.",),
        common_mistakes=("Divide energy by time.",),
        solve=lambda k: _q(k, "energy") / _q(k, "time"),
    ),
    Formula(
        id="efficiency_from_useful_total_energy",
        domain="circuits",
        subfield="energy_efficiency",
        target="efficiency",
        required=("energy", "energy_2"),
        output_unit="dimensionless",
        expression="eta = E_useful / E_total",
        explanation_template="Efficiency is useful output energy divided by total input energy.",
        keywords=("efficiency", "useful energy", "total energy", "engine", "eta"),
        variables={"eta": "efficiency", "E_useful": "energy", "E_total": "energy_2"},
        conditions=("Both energies must refer to the same process and use compatible units.",),
        common_mistakes=("Report percent only after multiplying the dimensionless ratio by 100.",),
        solve=lambda k: _q(k, "energy") / _q(k, "energy_2"),
    ),
    Formula(
        id="total_energy_from_useful_efficiency",
        domain="circuits",
        subfield="energy_efficiency",
        target="energy",
        required=("energy_2", "efficiency"),
        output_unit="J",
        expression="E_total = E_useful / eta",
        explanation_template="Rearranging efficiency gives total input energy as E_total = E_useful/eta.",
        keywords=("efficiency", "total energy", "useful energy", "engine"),
        variables={"E_total": "energy", "E_useful": "energy_2", "eta": "efficiency"},
        conditions=("Efficiency is a dimensionless fraction, not a percent number unless converted first.",),
        common_mistakes=("Convert 25% to 0.25 before dividing.",),
        solve=lambda k: _q(k, "energy_2") / _q(k, "efficiency"),
    ),
    Formula(
        id="charge_from_current_time",
        domain="circuits",
        subfield="dc_circuits",
        target="charge",
        required=("current", "time"),
        output_unit="C",
        expression="Q = I * t",
        explanation_template="Electric charge transferred is Q = I * t.",
        keywords=("charge", "current", "time", "flow"),
        variables={"Q": "charge", "I": "current", "t": "time"},
        conditions=("Current is constant over the time interval.",),
        common_mistakes=("Use seconds for time when current is in amperes.",),
        solve=lambda k: _q(k, "current") * _q(k, "time"),
    ),
    Formula(
        id="current_from_charge_time",
        domain="circuits",
        subfield="dc_circuits",
        target="current",
        required=("charge", "time"),
        output_unit="A",
        expression="I = Q / t",
        explanation_template="Current is charge flow per unit time: I = Q / t.",
        keywords=("current", "charge", "time", "flow"),
        variables={"I": "current", "Q": "charge", "t": "time"},
        conditions=("Average current over the given time interval.",),
        common_mistakes=("Divide charge by time, not time by charge.",),
        solve=lambda k: _q(k, "charge") / _q(k, "time"),
    ),
    Formula(
        id="motion_distance_from_speed_time",
        domain="mechanics",
        subfield="kinematics",
        target="length",
        required=("speed", "time"),
        output_unit="m",
        expression="s = v * t",
        explanation_template="For uniform motion, distance is speed times time: s = v*t.",
        keywords=("distance", "range", "speed", "velocity", "time", "uniform speed"),
        variables={"s": "length", "v": "speed", "t": "time"},
        conditions=("Speed is constant over the time interval.",),
        common_mistakes=("Convert km/h to m/s and minutes or hours to seconds before multiplying.",),
        solve=lambda k: _q(k, "speed") * _q(k, "time"),
    ),
    Formula(
        id="motion_speed_from_distance_time",
        domain="mechanics",
        subfield="kinematics",
        target="speed",
        required=("length", "time"),
        output_unit="m/s",
        expression="v = s / t",
        explanation_template="For uniform motion, speed is distance divided by time.",
        keywords=("speed", "velocity", "distance", "time", "uniform speed"),
        variables={"v": "speed", "s": "length", "t": "time"},
        conditions=("Average or constant speed over the interval.",),
        common_mistakes=("Divide distance by time.",),
        solve=lambda k: _q(k, "length") / _q(k, "time"),
    ),
    Formula(
        id="motion_time_from_distance_speed",
        domain="mechanics",
        subfield="kinematics",
        target="time",
        required=("length", "speed"),
        output_unit="s",
        expression="t = s / v",
        explanation_template="For uniform motion, time is distance divided by speed.",
        keywords=("time", "distance", "speed", "velocity"),
        variables={"t": "time", "s": "length", "v": "speed"},
        conditions=("Average or constant speed over the interval.",),
        common_mistakes=("Divide distance by speed.",),
        solve=lambda k: _q(k, "length") / _q(k, "speed"),
    ),
    Formula(
        id="work_from_force_distance",
        domain="mechanics",
        subfield="work_power_energy",
        target="energy",
        required=("force", "length"),
        output_unit="J",
        expression="W = F * s",
        explanation_template="Work done by a constant force along the displacement is W = F*s.",
        keywords=("work", "force", "distance", "displacement", "traction"),
        variables={"W": "energy", "F": "force", "s": "length"},
        conditions=("Force is parallel to displacement or already the component along motion.",),
        common_mistakes=("Use distance in meters; do not use fuel calorific value unless asked for heat input.",),
        solve=lambda k: _q(k, "force") * _q(k, "length"),
    ),
    Formula(
        id="force_from_work_distance",
        domain="mechanics",
        subfield="work_power_energy",
        target="force",
        required=("energy", "length"),
        output_unit="N",
        expression="F = W / s",
        explanation_template="Rearranging W = F*s gives F = W/s.",
        keywords=("force", "work", "distance", "displacement", "traction"),
        variables={"F": "force", "W": "energy", "s": "length"},
        conditions=("Force is parallel to displacement or already the component along motion.",),
        common_mistakes=("Divide work by distance.",),
        solve=lambda k: _q(k, "energy") / _q(k, "length"),
    ),
    Formula(
        id="distance_from_work_force",
        domain="mechanics",
        subfield="work_power_energy",
        target="length",
        required=("energy", "force"),
        output_unit="m",
        expression="s = W / F",
        explanation_template="Rearranging W = F*s gives distance s = W/F.",
        keywords=("distance", "work", "force", "traction"),
        variables={"s": "length", "W": "energy", "F": "force"},
        conditions=("Force is constant and parallel to displacement.",),
        common_mistakes=("Divide work by force.",),
        solve=lambda k: _q(k, "energy") / _q(k, "force"),
    ),
    Formula(
        id="power_from_force_speed",
        domain="mechanics",
        subfield="work_power_energy",
        target="power",
        required=("force", "speed"),
        output_unit="W",
        expression="P = F * v",
        explanation_template="At constant speed, mechanical power is force times speed: P = F*v.",
        keywords=("power", "force", "speed", "velocity", "traction"),
        variables={"P": "power", "F": "force", "v": "speed"},
        conditions=("Force is parallel to velocity.",),
        common_mistakes=("Convert speed to m/s before multiplying by newtons.",),
        solve=lambda k: _q(k, "force") * _q(k, "speed"),
    ),
    Formula(
        id="force_from_power_speed",
        domain="mechanics",
        subfield="work_power_energy",
        target="force",
        required=("power", "speed"),
        output_unit="N",
        expression="F = P / v",
        explanation_template="Rearranging P = F*v gives force F = P/v.",
        keywords=("force", "power", "speed", "traction"),
        variables={"F": "force", "P": "power", "v": "speed"},
        conditions=("Force is parallel to velocity.",),
        common_mistakes=("Divide power by speed.",),
        solve=lambda k: _q(k, "power") / _q(k, "speed"),
    ),
    Formula(
        id="speed_from_power_force",
        domain="mechanics",
        subfield="work_power_energy",
        target="speed",
        required=("power", "force"),
        output_unit="m/s",
        expression="v = P / F",
        explanation_template="Rearranging P = F*v gives speed v = P/F.",
        keywords=("speed", "power", "force", "traction"),
        variables={"v": "speed", "P": "power", "F": "force"},
        conditions=("Force is parallel to velocity.",),
        common_mistakes=("Divide power by force.",),
        solve=lambda k: _q(k, "power") / _q(k, "force"),
    ),
    Formula(
        id="heat_from_mass_specific_heat_temperature_change",
        domain="thermal",
        subfield="heat_capacity",
        target="energy",
        required=("mass", "specific_heat_capacity", "temperature"),
        output_unit="J",
        expression="Q = m * c * DeltaT",
        explanation_template="Heat absorbed for a temperature change is Q = m*c*DeltaT.",
        keywords=("heat", "specific heat capacity", "temperature change", "temperature rise", "water"),
        variables={"Q": "energy", "m": "mass", "c": "specific_heat_capacity", "DeltaT": "temperature"},
        conditions=("The temperature quantity is a temperature difference, not an absolute Celsius temperature.",),
        common_mistakes=("Use the temperature change, not the final temperature alone.",),
        solve=lambda k: _q(k, "mass") * _q(k, "specific_heat_capacity") * _q(k, "temperature"),
    ),
    Formula(
        id="temperature_change_from_heat_mass_specific_heat",
        domain="thermal",
        subfield="heat_capacity",
        target="temperature",
        required=("energy", "mass", "specific_heat_capacity"),
        output_unit="kelvin",
        expression="DeltaT = Q / (m*c)",
        explanation_template="Temperature change is heat divided by mass and specific heat capacity.",
        keywords=("temperature change", "temperature rise", "heat", "specific heat capacity"),
        variables={"DeltaT": "temperature", "Q": "energy", "m": "mass", "c": "specific_heat_capacity"},
        conditions=("Computes a temperature difference; kelvin difference equals Celsius degree difference.",),
        common_mistakes=("Divide by both mass and specific heat capacity.",),
        solve=lambda k: _q(k, "energy") / (_q(k, "mass") * _q(k, "specific_heat_capacity")),
    ),
    Formula(
        id="mass_from_heat_specific_heat_temperature_change",
        domain="thermal",
        subfield="heat_capacity",
        target="mass",
        required=("energy", "specific_heat_capacity", "temperature"),
        output_unit="kg",
        expression="m = Q / (c*DeltaT)",
        explanation_template="Mass is heat divided by specific heat capacity and temperature change.",
        keywords=("mass", "heat", "specific heat capacity", "temperature change"),
        variables={"m": "mass", "Q": "energy", "c": "specific_heat_capacity", "DeltaT": "temperature"},
        conditions=("The temperature quantity is a temperature difference.",),
        common_mistakes=("Divide by c*DeltaT.",),
        solve=lambda k: _q(k, "energy") / (_q(k, "specific_heat_capacity") * _q(k, "temperature")),
    ),
    Formula(
        id="heat_from_fuel_mass_calorific_value",
        domain="thermal",
        subfield="fuel_combustion",
        target="energy",
        required=("mass", "heat_of_combustion"),
        output_unit="J",
        expression="Q = m * q",
        explanation_template="Heat released by complete combustion is Q = m*q.",
        keywords=("heat released", "complete combustion", "fuel", "calorific value", "heat value"),
        variables={"Q": "energy", "m": "mass", "q": "heat_of_combustion"},
        conditions=("Fuel burns completely and q is the calorific value per unit mass.",),
        common_mistakes=("Convert grams to kilograms when q is in J/kg.",),
        solve=lambda k: _q(k, "mass") * _q(k, "heat_of_combustion"),
    ),
    Formula(
        id="fuel_mass_from_heat_calorific_value",
        domain="thermal",
        subfield="fuel_combustion",
        target="mass",
        required=("energy", "heat_of_combustion"),
        output_unit="kg",
        expression="m = Q / q",
        explanation_template="Fuel mass is released heat divided by calorific value.",
        keywords=("fuel mass", "heat released", "calorific value", "combustion"),
        variables={"m": "mass", "Q": "energy", "q": "heat_of_combustion"},
        conditions=("Fuel burns completely and q is the calorific value per unit mass.",),
        common_mistakes=("Divide heat by calorific value.",),
        solve=lambda k: _q(k, "energy") / _q(k, "heat_of_combustion"),
    ),
    Formula(
        id="series_resistance",
        domain="circuits",
        subfield="dc_circuits",
        target="resistance",
        required=("resistance", "resistance_2"),
        output_unit="ohm",
        expression="R_eq = R1 + R2",
        explanation_template="For two resistors in series, equivalent resistance is R_eq = R1 + R2.",
        keywords=("series", "equivalent resistance", "resistors"),
        variables={"R_eq": "resistance", "R1": "resistance", "R2": "resistance_2"},
        conditions=("Two resistors connected in series.",),
        common_mistakes=("Do not use the reciprocal formula for series resistors.",),
        solve=lambda k: _q(k, "resistance") + _q(k, "resistance_2"),
    ),
    Formula(
        id="parallel_resistance_two",
        domain="circuits",
        subfield="dc_circuits",
        target="resistance",
        required=("resistance", "resistance_2"),
        output_unit="ohm",
        expression="R_eq = R1 * R2 / (R1 + R2)",
        explanation_template="For two resistors in parallel, R_eq = R1R2/(R1+R2).",
        keywords=("parallel", "equivalent resistance", "resistors"),
        variables={"R_eq": "resistance", "R1": "resistance", "R2": "resistance_2"},
        conditions=("Two resistors connected in parallel.",),
        common_mistakes=("Parallel equivalent resistance is less than either branch resistance.",),
        solve=lambda k: (_q(k, "resistance") * _q(k, "resistance_2"))
        / (_q(k, "resistance") + _q(k, "resistance_2")),
    ),
    Formula(
        id="series_resistance_three",
        domain="circuits",
        subfield="dc_circuits",
        target="resistance",
        required=("resistance", "resistance_2", "resistance_3"),
        output_unit="ohm",
        expression="R_eq = R1 + R2 + R3",
        explanation_template="For three resistors in series, equivalent resistance is R_eq = R1 + R2 + R3.",
        keywords=("series", "equivalent resistance", "resistors", "three"),
        variables={"R_eq": "resistance", "R1": "resistance", "R2": "resistance_2", "R3": "resistance_3"},
        conditions=("Three resistors connected in series.",),
        common_mistakes=("Series resistances add directly.",),
        solve=lambda k: _q(k, "resistance") + _q(k, "resistance_2") + _q(k, "resistance_3"),
    ),
    Formula(
        id="parallel_resistance_three",
        domain="circuits",
        subfield="dc_circuits",
        target="resistance",
        required=("resistance", "resistance_2", "resistance_3"),
        output_unit="ohm",
        expression="1/R_eq = 1/R1 + 1/R2 + 1/R3",
        explanation_template="For three resistors in parallel, reciprocal equivalent resistance is the sum of reciprocals.",
        keywords=("parallel", "equivalent resistance", "resistors", "three"),
        variables={"R_eq": "resistance", "R1": "resistance", "R2": "resistance_2", "R3": "resistance_3"},
        conditions=("Three resistors connected in parallel.",),
        common_mistakes=("Use reciprocal sum for parallel resistors.",),
        solve=lambda k: 1
        / (1 / _q(k, "resistance") + 1 / _q(k, "resistance_2") + 1 / _q(k, "resistance_3")),
    ),
    Formula(
        id="capacitance_from_charge_voltage",
        domain="capacitance",
        subfield="capacitor_basics",
        target="capacitance",
        required=("charge", "voltage"),
        output_unit="F",
        expression="C = Q / U",
        explanation_template="Capacitance is charge divided by voltage: C = Q / U.",
        keywords=("capacitance", "capacitor", "charge", "voltage"),
        variables={"C": "capacitance", "Q": "charge", "U": "voltage"},
        conditions=("Charge and voltage are across the same capacitor.",),
        common_mistakes=("Use capacitance units, not charge units, for the final answer.",),
        solve=lambda k: _q(k, "charge") / _q(k, "voltage"),
    ),
    Formula(
        id="charge_from_capacitance_voltage",
        domain="capacitance",
        subfield="capacitor_basics",
        target="charge",
        required=("capacitance", "voltage"),
        output_unit="C",
        expression="Q = C * U",
        explanation_template="A capacitor stores charge Q = C * U.",
        keywords=("charge", "capacitor", "capacitance", "voltage"),
        variables={"Q": "charge", "C": "capacitance", "U": "voltage"},
        conditions=("Capacitance and voltage are for the same capacitor.",),
        common_mistakes=("Convert microfarads before multiplying by volts.",),
        solve=lambda k: _q(k, "capacitance") * _q(k, "voltage"),
    ),
    Formula(
        id="voltage_from_charge_capacitance",
        domain="capacitance",
        subfield="capacitor_basics",
        target="voltage",
        required=("charge", "capacitance"),
        output_unit="V",
        expression="U = Q / C",
        explanation_template="For a capacitor, voltage is U = Q / C.",
        keywords=("voltage", "potential difference", "capacitor", "charge", "capacitance"),
        variables={"U": "voltage", "Q": "charge", "C": "capacitance"},
        conditions=("Charge and capacitance are for the same capacitor.",),
        common_mistakes=("Voltage is charge divided by capacitance.",),
        solve=lambda k: _q(k, "charge") / _q(k, "capacitance"),
    ),
    Formula(
        id="capacitor_energy",
        domain="capacitance",
        subfield="capacitor_energy",
        target="energy",
        required=("capacitance", "voltage"),
        output_unit="J",
        expression="W = 1/2 * C * U^2",
        explanation_template="The energy stored in a capacitor is W = 1/2 * C * U^2.",
        keywords=("energy", "stored", "capacitor", "capacitance", "voltage"),
        variables={"W": "energy", "C": "capacitance", "U": "voltage"},
        conditions=("Capacitance and voltage are for the same charged capacitor.",),
        common_mistakes=("Remember the factor 1/2 and square the voltage.",),
        solve=lambda k: 0.5 * _q(k, "capacitance") * (_q(k, "voltage") ** 2),
    ),
    Formula(
        id="capacitor_energy_from_charge_voltage",
        domain="capacitance",
        subfield="capacitor_energy",
        target="energy",
        required=("charge", "voltage"),
        output_unit="J",
        expression="W = 1/2 * Q * U",
        explanation_template="The energy stored in a capacitor can be computed as W = 1/2 * Q * U.",
        keywords=("energy", "stored", "capacitor", "charge", "voltage"),
        variables={"W": "energy", "Q": "charge", "U": "voltage"},
        conditions=("Charge and voltage refer to the same charged capacitor.",),
        common_mistakes=("Remember the factor 1/2.",),
        solve=lambda k: 0.5 * _q(k, "charge") * _q(k, "voltage"),
    ),
    Formula(
        id="capacitor_energy_from_charge_capacitance",
        domain="capacitance",
        subfield="capacitor_energy",
        target="energy",
        required=("charge", "capacitance"),
        output_unit="J",
        expression="W = Q^2 / (2C)",
        explanation_template="The energy stored in a capacitor can be computed as W = Q^2/(2C).",
        keywords=("energy", "stored", "capacitor", "charge", "capacitance"),
        variables={"W": "energy", "Q": "charge", "C": "capacitance"},
        conditions=("Charge and capacitance refer to the same charged capacitor.",),
        common_mistakes=("Square the charge and divide by twice the capacitance.",),
        solve=lambda k: (_q(k, "charge") ** 2) / (2 * _q(k, "capacitance")),
    ),
    Formula(
        id="voltage_from_capacitor_energy_capacitance",
        domain="capacitance",
        subfield="capacitor_energy",
        target="voltage",
        required=("energy", "capacitance"),
        output_unit="V",
        expression="U = sqrt(2W / C)",
        explanation_template="Rearranging W = 1/2CU^2 gives U = sqrt(2W/C).",
        keywords=("voltage", "energy", "capacitor", "capacitance"),
        variables={"U": "voltage", "W": "energy", "C": "capacitance"},
        conditions=("Energy and capacitance refer to the same capacitor.",),
        common_mistakes=("Take the square root after dividing 2W by C.",),
        solve=lambda k: ((2 * _q(k, "energy")) / _q(k, "capacitance")) ** 0.5,
    ),
    Formula(
        id="voltage_disconnected_capacitor_insert_dielectric",
        domain="capacitance",
        subfield="dielectrics",
        target="voltage",
        required=("voltage", "relative_permittivity"),
        output_unit="V",
        expression="U_new = U / epsilon_r",
        explanation_template=(
            "For a disconnected charged capacitor, charge remains constant. Inserting a dielectric increases "
            "capacitance by epsilon_r, so the voltage becomes U_new = U / epsilon_r."
        ),
        keywords=("disconnected", "dielectric", "dielectric constant", "relative permittivity", "potential difference", "voltage"),
        variables={"U_new": "voltage", "U": "voltage", "epsilon_r": "relative_permittivity"},
        conditions=("The capacitor is disconnected from the source before the dielectric is inserted.",),
        common_mistakes=("Do not keep voltage constant after disconnection; charge remains constant instead.",),
        solve=lambda k: _q(k, "voltage") / _q(k, "relative_permittivity"),
    ),
    Formula(
        id="voltage_connected_capacitor_insert_dielectric",
        domain="capacitance",
        subfield="dielectrics",
        target="voltage",
        required=("voltage",),
        output_unit="V",
        expression="U_new = U",
        explanation_template=(
            "When the capacitor remains connected to the voltage source, the source holds the potential "
            "difference constant while charge adjusts."
        ),
        keywords=("still connected", "connected to the source", "voltage source", "dielectric", "potential difference", "voltage"),
        variables={"U_new": "voltage", "U": "voltage"},
        conditions=("The capacitor remains connected to the voltage source.",),
        common_mistakes=("Do not treat charge as constant while the voltage source remains connected.",),
        solve=lambda k: _q(k, "voltage"),
    ),
    Formula(
        id="energy_disconnected_capacitor_insert_dielectric",
        domain="capacitance",
        subfield="dielectrics",
        target="energy",
        required=("capacitance", "voltage", "relative_permittivity"),
        output_unit="J",
        expression="W_new = (1/2 * C * U^2) / epsilon_r",
        explanation_template=(
            "For a disconnected capacitor, charge remains constant and inserting a dielectric increases "
            "capacitance by epsilon_r, so stored energy decreases by epsilon_r."
        ),
        keywords=("disconnected", "dielectric", "relative permittivity", "dielectric constant", "electric field energy", "energy"),
        variables={"W_new": "energy", "C": "capacitance", "U": "voltage", "epsilon_r": "relative_permittivity"},
        conditions=("The capacitor is disconnected before insertion of the dielectric.",),
        common_mistakes=("Do not use the original voltage after the dielectric is inserted.",),
        solve=lambda k: 0.5
        * _q(k, "capacitance")
        * (_q(k, "voltage") ** 2)
        / _q(k, "relative_permittivity"),
    ),
    Formula(
        id="energy_connected_capacitor_insert_dielectric",
        domain="capacitance",
        subfield="dielectrics",
        target="energy",
        required=("capacitance", "voltage", "relative_permittivity"),
        output_unit="J",
        expression="W_new = 1/2 * epsilon_r * C * U^2",
        explanation_template=(
            "When the capacitor remains connected to the voltage source, voltage stays constant and "
            "the dielectric increases capacitance by epsilon_r, so W_new = 1/2 * epsilon_r * C * U^2."
        ),
        keywords=("still connected", "connected to the voltage source", "connected to the source", "dielectric", "electric field energy", "energy"),
        variables={"W_new": "energy", "C": "capacitance", "U": "voltage", "epsilon_r": "relative_permittivity"},
        conditions=("The capacitor remains connected to the voltage source while the dielectric is inserted.",),
        common_mistakes=("Do not keep charge constant while the voltage source remains connected.",),
        solve=lambda k: 0.5
        * _q(k, "relative_permittivity")
        * _q(k, "capacitance")
        * (_q(k, "voltage") ** 2),
    ),
    Formula(
        id="capacitance_parallel_plate_distance_doubled",
        domain="capacitance",
        subfield="parallel_plate",
        target="capacitance",
        required=("capacitance",),
        output_unit="F",
        expression="C_new = C / 2",
        explanation_template=(
            "For a parallel-plate capacitor, capacitance is inversely proportional to plate separation. "
            "Doubling the distance halves the capacitance."
        ),
        keywords=("plates", "moved apart", "distance", "doubled", "new capacitance", "capacitance"),
        variables={"C_new": "capacitance", "C": "capacitance"},
        conditions=("The plate distance is doubled while plate area and medium remain unchanged.",),
        common_mistakes=("Do not double capacitance; C is inversely proportional to distance.",),
        solve=lambda k: _q(k, "capacitance") / 2,
    ),
    Formula(
        id="voltage_disconnected_capacitor_distance_doubled",
        domain="capacitance",
        subfield="parallel_plate",
        target="voltage",
        required=("voltage",),
        output_unit="V",
        expression="U_new = 2 * U",
        explanation_template=(
            "After disconnection, charge remains constant. Doubling plate separation halves capacitance, "
            "so U_new = Q/(C/2) = 2U."
        ),
        keywords=("disconnected", "power source", "moved apart", "distance", "doubles", "potential difference", "voltage"),
        variables={"U_new": "voltage", "U": "voltage"},
        conditions=("The capacitor is disconnected and then the plate distance is doubled.",),
        common_mistakes=("Do not keep voltage constant after disconnection.",),
        solve=lambda k: 2 * _q(k, "voltage"),
    ),
    Formula(
        id="voltage_connected_capacitor_distance_changed",
        domain="capacitance",
        subfield="parallel_plate",
        target="voltage",
        required=("voltage",),
        output_unit="V",
        expression="U_new = U",
        explanation_template=(
            "While the capacitor remains connected to the source, the source maintains the same potential "
            "difference even if the plate distance changes."
        ),
        keywords=("still connected", "connected to the source", "plates", "moved", "distance", "potential difference", "voltage"),
        variables={"U_new": "voltage", "U": "voltage"},
        conditions=("The capacitor remains connected to the source while plate separation changes.",),
        common_mistakes=("Do not conserve charge while the voltage source is still connected.",),
        solve=lambda k: _q(k, "voltage"),
    ),
    Formula(
        id="charge_parallel_plate_circular_air_capacitor",
        domain="capacitance",
        subfield="parallel_plate",
        target="charge",
        required=("length", "length_2", "voltage"),
        output_unit="C",
        expression="Q = epsilon_0 * pi * r^2 * U / d",
        explanation_template=(
            "For an air-filled circular parallel-plate capacitor, C = epsilon_0*pi*r^2/d and Q = C*U."
        ),
        keywords=("parallel-plate", "circular plates", "radius", "distance between the plates", "potential difference", "charge"),
        variables={"Q": "charge", "r": "length", "d": "length_2", "U": "voltage"},
        conditions=("Circular air-filled parallel plates with radius r and separation d.",),
        common_mistakes=("Use plate area pi*r^2, not circumference.",),
        solve=lambda k: EPSILON_0
        * math.pi
        * (_q(k, "length") ** 2)
        * _q(k, "voltage")
        / _q(k, "length_2"),
    ),
    Formula(
        id="charge_from_capacitor_energy_capacitance",
        domain="capacitance",
        subfield="capacitor_energy",
        target="charge",
        required=("energy", "capacitance"),
        output_unit="C",
        expression="Q = sqrt(2WC)",
        explanation_template="Rearranging W = Q^2/(2C) gives Q = sqrt(2WC).",
        keywords=("charge", "energy", "capacitor", "capacitance"),
        variables={"Q": "charge", "W": "energy", "C": "capacitance"},
        conditions=("Energy and capacitance refer to the same capacitor.",),
        common_mistakes=("Take the square root after multiplying 2W by C.",),
        solve=lambda k: (2 * _q(k, "energy") * _q(k, "capacitance")) ** 0.5,
    ),
    Formula(
        id="inductor_energy",
        domain="inductance",
        subfield="inductor_energy",
        target="energy",
        required=("inductance", "current"),
        output_unit="J",
        expression="W = 1/2 * L * I^2",
        explanation_template="The magnetic energy stored in an inductor is W = 1/2 * L * I^2.",
        keywords=("energy", "magnetic", "inductor", "inductance", "current"),
        variables={"W": "energy", "L": "inductance", "I": "current"},
        conditions=("Inductance and current are for the same inductor.",),
        common_mistakes=("Remember the factor 1/2 and square the current.",),
        solve=lambda k: 0.5 * _q(k, "inductance") * (_q(k, "current") ** 2),
    ),
    Formula(
        id="inductance_from_energy_current",
        domain="inductance",
        subfield="inductor_energy",
        target="inductance",
        required=("energy", "current"),
        output_unit="H",
        expression="L = 2W / I^2",
        explanation_template="Rearranging W = 1/2*L*I^2 gives L = 2W/I^2.",
        keywords=("inductance", "energy", "current", "inductor"),
        variables={"L": "inductance", "W": "energy", "I": "current"},
        conditions=("Energy and current refer to the same inductor.",),
        common_mistakes=("Divide twice the energy by the square of current.",),
        solve=lambda k: 2 * _q(k, "energy") / (_q(k, "current") ** 2),
    ),
    Formula(
        id="lc_natural_frequency",
        domain="circuits",
        subfield="lc_oscillation",
        target="frequency",
        required=("inductance", "capacitance"),
        output_unit="Hz",
        expression="f = 1 / (2*pi*sqrt(L*C))",
        explanation_template="The natural oscillation frequency of an ideal LC circuit is f = 1/(2*pi*sqrt(LC)).",
        keywords=("natural oscillation frequency", "lc circuit", "resonant frequency", "oscillation", "frequency", "inductance", "capacitance"),
        variables={"f": "frequency", "L": "inductance", "C": "capacitance"},
        conditions=("Ideal LC circuit with inductance L and capacitance C.",),
        common_mistakes=("Use frequency f in hertz, not angular frequency omega = 1/sqrt(LC)."),
        solve=lambda k: 1 / (2 * math.pi * ((_q(k, "inductance") * _q(k, "capacitance")) ** 0.5)),
    ),
    Formula(
        id="lc_natural_angular_frequency",
        domain="circuits",
        subfield="lc_oscillation",
        target="angular_frequency",
        required=("inductance", "capacitance"),
        output_unit="rad/s",
        expression="omega = 1 / sqrt(L*C)",
        explanation_template="The natural angular frequency of an ideal LC circuit is omega = 1/sqrt(LC).",
        keywords=("angular frequency", "lc circuit", "resonant", "inductance", "capacitance"),
        variables={"omega": "angular_frequency", "L": "inductance", "C": "capacitance"},
        conditions=("Ideal LC circuit with inductance L and capacitance C.",),
        common_mistakes=("Angular frequency is in rad/s, not hertz.",),
        solve=lambda k: 1 / ((_q(k, "inductance") * _q(k, "capacitance")) ** 0.5),
    ),
    Formula(
        id="lc_natural_period",
        domain="circuits",
        subfield="lc_oscillation",
        target="time",
        required=("inductance", "capacitance"),
        output_unit="s",
        expression="T = 2*pi*sqrt(L*C)",
        explanation_template="The natural period of an ideal LC circuit is T = 2*pi*sqrt(LC).",
        keywords=("period", "oscillation", "lc circuit", "inductance", "capacitance"),
        variables={"T": "time", "L": "inductance", "C": "capacitance"},
        conditions=("Ideal LC circuit with inductance L and capacitance C.",),
        common_mistakes=("Use the square root of LC and multiply by 2*pi.",),
        solve=lambda k: 2 * math.pi * ((_q(k, "inductance") * _q(k, "capacitance")) ** 0.5),
    ),
    Formula(
        id="period_from_frequency",
        domain="waves",
        subfield="oscillation",
        target="time",
        required=("frequency",),
        output_unit="s",
        expression="T = 1 / f",
        explanation_template="The period is the reciprocal of frequency: T = 1/f.",
        keywords=("period", "frequency", "oscillation"),
        variables={"T": "time", "f": "frequency"},
        conditions=("Frequency is positive and constant.",),
        common_mistakes=("Inverse frequency gives period.",),
        solve=lambda k: 1 / _q(k, "frequency"),
    ),
    Formula(
        id="frequency_from_period",
        domain="waves",
        subfield="oscillation",
        target="frequency",
        required=("time",),
        output_unit="Hz",
        expression="f = 1 / T",
        explanation_template="The frequency is the reciprocal of period: f = 1/T.",
        keywords=("frequency", "period", "oscillation"),
        variables={"f": "frequency", "T": "time"},
        conditions=("Period is positive and constant.",),
        common_mistakes=("Inverse period gives frequency.",),
        solve=lambda k: 1 / _q(k, "time"),
    ),
    Formula(
        id="electric_field_from_force_charge",
        domain="electrostatics",
        subfield="electric_field",
        target="electric_field",
        required=("force", "charge"),
        output_unit="V/m",
        expression="E = F / q",
        explanation_template="Electric field strength is force per unit charge: E = F / q.",
        keywords=("electric field", "field strength", "force", "charge"),
        variables={"E": "electric_field", "F": "force", "q": "charge"},
        conditions=("Force acts on the same test charge q.",),
        common_mistakes=("Electric field is force divided by charge.",),
        solve=lambda k: _q(k, "force") / _q(k, "charge"),
    ),
    Formula(
        id="electric_field_point_charge",
        domain="electrostatics",
        subfield="coulomb_law",
        target="electric_field",
        required=("charge", "length"),
        output_unit="N/C",
        expression="E = k * |q| / r^2",
        explanation_template="The electric field of a point charge is E = k * |q| / r^2.",
        keywords=("electric field", "point charge", "field", "charge", "distance"),
        variables={"E": "electric_field", "q": "charge", "r": "length"},
        conditions=("Point charge or spherical symmetry; r is the distance from the charge.",),
        common_mistakes=("Use the square of the distance in the denominator.",),
        solve=lambda k: K_COULOMB * abs(_q(k, "charge")) / (_q(k, "length") ** 2),
    ),
    Formula(
        id="electric_field_uniform_from_voltage_distance",
        domain="electrostatics",
        subfield="electric_field",
        target="electric_field",
        required=("voltage", "length"),
        output_unit="V/m",
        expression="E = U / d",
        explanation_template="For a uniform electric field, E = U/d.",
        keywords=("electric field", "voltage", "potential difference", "distance", "uniform"),
        variables={"E": "electric_field", "U": "voltage", "d": "length"},
        conditions=("Uniform electric field between two points or plates separated by distance d.",),
        common_mistakes=("Divide voltage by distance.",),
        solve=lambda k: _q(k, "voltage") / _q(k, "length"),
    ),
    Formula(
        id="voltage_from_uniform_electric_field",
        domain="electrostatics",
        subfield="electric_field",
        target="voltage",
        required=("electric_field", "length"),
        output_unit="V",
        expression="U = E * d",
        explanation_template="For a uniform electric field, potential difference is U = E*d.",
        keywords=("voltage", "potential difference", "electric field", "distance", "uniform"),
        variables={"U": "voltage", "E": "electric_field", "d": "length"},
        conditions=("Uniform electric field along the displacement direction.",),
        common_mistakes=("Multiply field strength by distance.",),
        solve=lambda k: _q(k, "electric_field") * _q(k, "length"),
    ),
    Formula(
        id="electric_potential_point_charge",
        domain="electrostatics",
        subfield="electric_potential",
        target="voltage",
        required=("charge", "length"),
        output_unit="V",
        expression="V = k * q / r",
        explanation_template="The electric potential of a point charge is V = k*q/r.",
        keywords=("electric potential", "voltage", "point charge", "distance"),
        variables={"V": "voltage", "q": "charge", "r": "length"},
        conditions=("Point charge potential relative to infinity.",),
        common_mistakes=("Use r in the denominator, not r squared.",),
        solve=lambda k: K_COULOMB * _q(k, "charge") / _q(k, "length"),
    ),
    Formula(
        id="electric_dipole_moment_magnitude",
        domain="electrostatics",
        subfield="electric_dipoles",
        target="electric_dipole_moment",
        required=("charge", "length"),
        output_unit="C * m",
        expression="p = q * a",
        explanation_template="Electric dipole moment magnitude is charge times separation: p = q*a.",
        keywords=("dipole moment", "electric dipole", "charge", "separation"),
        variables={"p": "electric_dipole_moment", "q": "charge", "a": "length"},
        conditions=("The displacement a is from negative charge to positive charge; this formula returns magnitude.",),
        common_mistakes=("Use the charge magnitude of one pole, not the sum of both charges.",),
        solve=lambda k: abs(_q(k, "charge")) * _q(k, "length"),
    ),
    Formula(
        id="electric_field_infinite_flat_sheet",
        domain="electrostatics",
        subfield="electric_field",
        target="electric_field",
        required=("surface_charge_density",),
        output_unit="N/C",
        expression="E = sigma / (2*epsilon_0)",
        explanation_template="An infinite uniformly charged sheet produces field magnitude E = sigma/(2 epsilon_0).",
        keywords=("infinite flat surface", "sheet", "surface charge density", "electric field"),
        variables={"E": "electric_field", "sigma": "surface_charge_density"},
        conditions=("Infinite flat sheet of charge in vacuum/air; field magnitude on either side.",),
        common_mistakes=("Do not multiply by distance; the ideal infinite sheet field is constant.",),
        solve=lambda k: abs(_q(k, "surface_charge_density")) / (2 * EPSILON_0),
    ),
    Formula(
        id="electric_field_infinite_line_charge",
        domain="electrostatics",
        subfield="electric_field",
        target="electric_field",
        required=("linear_charge_density", "length"),
        output_unit="N/C",
        expression="E = lambda / (2*pi*epsilon_0*r)",
        explanation_template="An infinite line charge gives field magnitude E = lambda/(2*pi*epsilon_0*r).",
        keywords=("infinite line", "line charge", "linear charge density", "electric field", "distance"),
        variables={"E": "electric_field", "lambda": "linear_charge_density", "r": "length"},
        conditions=("Infinite straight line charge in vacuum/air; r is radial distance from the line.",),
        common_mistakes=("Use r, not r squared, for an infinite line charge.",),
        solve=lambda k: abs(_q(k, "linear_charge_density")) / (2 * math.pi * EPSILON_0 * _q(k, "length")),
    ),
    Formula(
        id="force_from_field_charge",
        domain="electrostatics",
        subfield="electric_field",
        target="force",
        required=("electric_field", "charge"),
        output_unit="N",
        expression="F = q * E",
        explanation_template="The electric force on a charge in a field is F = q * E.",
        keywords=("electric force", "force", "electric field", "charge"),
        variables={"F": "force", "q": "charge", "E": "electric_field"},
        conditions=("Charge is placed in the given electric field.",),
        common_mistakes=("Use field strength times charge, not divide by charge.",),
        solve=lambda k: _q(k, "charge") * _q(k, "electric_field"),
    ),
    Formula(
        id="coulomb_force",
        domain="electrostatics",
        subfield="coulomb_law",
        target="force",
        required=("charge", "charge_2", "length"),
        output_unit="N",
        expression="F = k * |q1*q2| / r^2",
        explanation_template="Coulomb's law gives the force magnitude as F = k * |q1*q2| / r^2.",
        keywords=("electric force", "force", "charges", "charge", "separated", "distance"),
        variables={"F": "force", "q1": "charge", "q2": "charge_2", "r": "length"},
        conditions=("Point charges or spherically symmetric charges; r is separation distance.",),
        common_mistakes=("Put r squared in the denominator.", "Use both charges, q1 and q2."),
        solve=lambda k: K_COULOMB * abs(_q(k, "charge") * _q(k, "charge_2")) / (_q(k, "length") ** 2),
    ),
    Formula(
        id="resultant_two_forces_angle",
        domain="electrostatics",
        subfield="vector_forces",
        target="force",
        required=("force", "force_2", "angle"),
        output_unit="N",
        expression="R = sqrt(F1^2 + F2^2 + 2*F1*F2*cos(theta))",
        explanation_template="The resultant of two force vectors with included angle theta uses the cosine rule.",
        keywords=("resultant", "two forces", "angle", "force", "vectors", "60"),
        variables={"R": "force", "F1": "force", "F2": "force_2", "theta": "angle"},
        conditions=("The angle is the included angle between the two force vectors.",),
        common_mistakes=(
            "Do not add force magnitudes as scalars unless the angle is zero.",
            "Use +2F1F2cos(theta) for the included angle.",
        ),
        solve=lambda k: (
            (_q(k, "force") ** 2)
            + (_q(k, "force_2") ** 2)
            + 2 * _q(k, "force") * _q(k, "force_2") * math.cos(_angle_radians(k))
        )
        ** 0.5,
    ),
    Formula(
        id="angle_between_two_forces_from_resultant",
        domain="electrostatics",
        subfield="vector_forces",
        target="angle",
        required=("force", "force_2", "resultant_force"),
        output_unit="degree",
        expression="theta = acos((R^2 - F1^2 - F2^2) / (2*F1*F2))",
        explanation_template=(
            "Rearrange the two-force resultant formula to solve for the included angle."
        ),
        keywords=("angle between", "two forces", "resultant", "force", "cos", "acos"),
        variables={"theta": "angle", "R": "resultant_force", "F1": "force", "F2": "force_2"},
        conditions=("R is the resultant magnitude of the two force vectors.",),
        common_mistakes=("Do not assume the forces are perpendicular unless the angle is given as 90 degrees.",),
        solve=_angle_between_forces_from_resultant,
    ),
    Formula(
        id="resultant_two_perpendicular_forces",
        domain="electrostatics",
        subfield="vector_forces",
        target="force",
        required=("force", "force_2"),
        output_unit="N",
        expression="R = sqrt(F1^2 + F2^2), for perpendicular forces",
        explanation_template="For perpendicular force components, the resultant is found by Pythagoras.",
        keywords=("perpendicular", "right angle", "right triangle", "net force", "resultant", "force"),
        variables={"R": "force", "F1": "force", "F2": "force_2"},
        conditions=("The two force vectors are perpendicular.",),
        common_mistakes=("Do not use sqrt(3) unless the included angle is 60 degrees with equal forces.",),
        solve=lambda k: ((_q(k, "force") ** 2) + (_q(k, "force_2") ** 2)) ** 0.5,
    ),
    Formula(
        id="coulomb_equal_charges_from_force",
        domain="electrostatics",
        subfield="coulomb_law",
        target="charge",
        required=("force", "length"),
        output_unit="C",
        expression="q = sqrt(F * r^2 / k), for |q1| = |q2| = q",
        explanation_template="For equal point charges, Coulomb's law rearranges to q = sqrt(F*r^2/k).",
        keywords=("charge", "charges", "force", "separated", "q1 = q2", "find q"),
        variables={"q": "charge", "F": "force", "r": "length"},
        conditions=("The two point charges have equal magnitude.",),
        common_mistakes=("Take the square root after solving for q squared.",),
        solve=lambda k: ((_q(k, "force") * (_q(k, "length") ** 2) / K_COULOMB) ** 0.5),
    ),
    Formula(
        id="net_force_equal_charges_right_angle",
        domain="electrostatics",
        subfield="coulomb_law",
        target="force",
        required=("charge", "length"),
        output_unit="N",
        expression="F_net = sqrt(2) * k * q^2 / a^2",
        explanation_template=(
            "For three equal charges at the vertices of an isosceles right triangle, "
            "the charge at the right-angle vertex feels two equal perpendicular forces."
        ),
        keywords=("isosceles right triangle", "right angle", "right triangle", "perpendicular", "net force", "charges"),
        variables={"F_net": "force", "q": "charge", "a": "length"},
        conditions=(
            "Three equal point charges at the vertices of an isosceles right triangle.",
            "The target charge is at the right-angle vertex and both legs have length a.",
        ),
        common_mistakes=("Use sqrt(2), not sqrt(3), because the two forces are perpendicular.",),
        solve=lambda k: math.sqrt(2) * K_COULOMB * (_q(k, "charge") ** 2) / (_q(k, "length") ** 2),
    ),
    Formula(
        id="net_force_three_collinear_middle_charge",
        domain="electrostatics",
        subfield="coulomb_law",
        target="force",
        required=("charge", "charge_2", "charge_3", "length"),
        output_unit="N",
        expression="F_net_on_q2 = |k|q1*q2|/r^2 - k|q3*q2|/r^2|",
        explanation_template=(
            "For three collinear charges with q2 between q1 and q3 at equal spacing, "
            "the two forces on q2 are opposite along the line, so subtract magnitudes."
        ),
        keywords=("straight line", "collinear", "force acting on q2", "three charges", "apart"),
        variables={"F_net": "force", "q1": "charge", "q2": "charge_2", "q3": "charge_3", "r": "length"},
        conditions=(
            "q1, q2, and q3 lie on a straight line.",
            "q2 is the middle target charge and each adjacent separation is r.",
        ),
        common_mistakes=("Do not return only one pairwise force; include both q1-on-q2 and q3-on-q2.",),
        solve=lambda k: abs(
            K_COULOMB * abs(_q(k, "charge") * _q(k, "charge_2")) / (_q(k, "length") ** 2)
            - K_COULOMB * abs(_q(k, "charge_3") * _q(k, "charge_2")) / (_q(k, "length") ** 2)
        ),
    ),
    Formula(
        id="net_force_midpoint_between_opposite_equal_charges",
        domain="electrostatics",
        subfield="coulomb_law",
        target="force",
        required=("charge", "charge_2", "charge_3", "length"),
        output_unit="N",
        expression="F_net_on_q3 = k*|q3|*(|q1|+|q2|)/(AB/2)^2",
        explanation_template=(
            "For q3 at the midpoint between opposite source charges q1 and q2, "
            "the attraction toward one source and repulsion from the other point in the same direction."
        ),
        keywords=(
            "midpoint",
            "points a and b",
            "ab",
            "q3",
            "charge",
            "charges",
            "electric force",
            "force",
            "opposite charges",
            "electric force acting on q3",
            "placed at the midpoint",
        ),
        variables={"F_net": "force", "q1": "charge", "q2": "charge_2", "q3": "charge_3", "AB": "length"},
        conditions=(
            "q3 is placed at the midpoint of segment AB.",
            "The two source charges at A and B have opposite signs so the two forces on q3 point in the same direction.",
        ),
        common_mistakes=("Use AB/2 as the distance from q3 to each source charge.",),
        solve=lambda k: K_COULOMB
        * abs(_q(k, "charge_3"))
        * (abs(_q(k, "charge")) + abs(_q(k, "charge_2")))
        / ((_q(k, "length") / 2) ** 2),
    ),
    Formula(
        id="net_force_three_charges_triangle_on_q3",
        domain="electrostatics",
        subfield="coulomb_law",
        target="force",
        required=("charge", "charge_2", "charge_3", "length", "length_2", "length_3"),
        output_unit="N",
        expression="F_net = |F13 + F23| using Coulomb forces and the law of cosines",
        explanation_template=(
            "For q3 at vertex C with source charges at A and B, compute the two Coulomb force "
            "magnitudes and combine them as vectors using the triangle side lengths."
        ),
        keywords=(
            "point c",
            "q3",
            "ca",
            "ac",
            "cb",
            "bc",
            "triangle",
            "magnitude of the electric force acting on q3",
            "force acting on q3",
        ),
        variables={
            "F_net": "force",
            "q1": "charge",
            "q2": "charge_2",
            "q3": "charge_3",
            "AC": "length",
            "BC": "length_2",
            "AB": "length_3",
        },
        conditions=(
            "q3 is at point C.",
            "length and length_2 are the distances from q3 to the two source charges.",
            "length_3 is the distance between the two source charges.",
        ),
        common_mistakes=(
            "Do not use the midpoint shortcut unless the problem explicitly says midpoint.",
            "Attraction reverses one force direction; combine force vectors, not only magnitudes.",
        ),
        solve=_net_force_on_third_charge_by_triangle_sides,
    ),
    Formula(
        id="net_force_right_triangle_at_a_from_b_c",
        domain="electrostatics",
        subfield="coulomb_law",
        target="force",
        required=("charge", "charge_2", "charge_3", "length", "length_2"),
        output_unit="N",
        expression="F_A = sqrt((k|qA*qB|/AB^2)^2 + (k|qA*qC|/AC^2)^2), AC=sqrt(BC^2-AB^2)",
        explanation_template=(
            "For a right triangle ABC right-angled at A, the forces on charge A from B and C "
            "are perpendicular; compute AC from AB and BC, then combine by Pythagoras."
        ),
        keywords=(
            "right-angled triangle",
            "right-angled at a",
            "right angle at a",
            "charge at a",
            "net electric force acting on the charge at a",
            "ab",
            "bc",
        ),
        variables={
            "F_A": "force",
            "qA": "charge",
            "qB": "charge_2",
            "qC": "charge_3",
            "AB": "length",
            "BC": "length_2",
        },
        conditions=(
            "ABC is right-angled at A.",
            "length is AB and length_2 is the hypotenuse BC.",
            "The target charge is at A.",
        ),
        common_mistakes=("Do not use BC as the distance from A to C; compute AC by Pythagoras.",),
        solve=_net_force_on_a_in_right_triangle,
    ),
    Formula(
        id="electric_potential_energy_two_point_charges",
        domain="electrostatics",
        subfield="coulomb_law",
        target="energy",
        required=("charge", "charge_2", "length"),
        output_unit="J",
        expression="U = k * q1 * q2 / r",
        explanation_template="The potential energy of two point charges is U = k * q1 * q2 / r.",
        keywords=("potential energy", "electric potential energy", "charges", "distance", "coulomb"),
        variables={"U": "energy", "q1": "charge", "q2": "charge_2", "r": "length"},
        conditions=("Point charges separated by distance r.",),
        common_mistakes=("Keep the distance in the denominator only once.",),
        solve=lambda k: K_COULOMB * _q(k, "charge") * _q(k, "charge_2") / _q(k, "length"),
    ),
    Formula(
        id="net_force_equal_coulomb_equilateral",
        domain="electrostatics",
        subfield="coulomb_law",
        target="force",
        required=("charge", "length"),
        output_unit="N",
        expression="F_net = sqrt(3) * k * q^2 / r^2",
        explanation_template=(
            "For three equal charges at the vertices of an equilateral triangle, "
            "the two equal Coulomb forces on one charge meet at 60 degrees, so "
            "F_net = sqrt(3) * k*q^2/r^2."
        ),
        keywords=("equilateral", "triangle", "net electric force", "resultant", "coulomb", "charges"),
        variables={"F_net": "force", "q": "charge", "r": "length"},
        conditions=(
            "Three equal point charges at the vertices of an equilateral triangle.",
            "Net force is the magnitude acting on one vertex charge due to the other two.",
        ),
        common_mistakes=("Do not add the two equal force magnitudes as scalars; include the 60 degree angle.",),
        solve=lambda k: math.sqrt(3) * K_COULOMB * (_q(k, "charge") ** 2) / (_q(k, "length") ** 2),
    ),
    Formula(
        id="net_force_two_equal_sources_equilateral_on_target",
        domain="electrostatics",
        subfield="coulomb_law",
        target="force",
        required=("charge", "charge_2", "length"),
        output_unit="N",
        expression="F_net = sqrt(3) * k * |q_source*q_target| / a^2",
        explanation_template=(
            "For two identical source charges at two vertices of an equilateral triangle, "
            "the forces on the third target charge have equal magnitude and meet at 60 degrees."
        ),
        keywords=("equilateral", "triangle", "two identical charges", "remaining vertex", "q'", "net electric force"),
        variables={"F_net": "force", "q_source": "charge", "q_target": "charge_2", "a": "length"},
        conditions=(
            "Two identical source charges occupy two vertices of an equilateral triangle.",
            "The target charge at the remaining vertex may have a different magnitude or sign.",
        ),
        common_mistakes=(
            "Use the target charge magnitude, not the source charge twice, when q' differs from q.",
            "Use vector resultant sqrt(3)*F for the two equal forces.",
        ),
        solve=lambda k: math.sqrt(3)
        * K_COULOMB
        * abs(_q(k, "charge") * _q(k, "charge_2"))
        / (_q(k, "length") ** 2),
    ),
    Formula(
        id="electric_field_two_equal_sources_equilateral",
        domain="electrostatics",
        subfield="coulomb_law",
        target="electric_field",
        required=("charge", "length"),
        output_unit="N/C",
        expression="E_net = sqrt(3) * k * |q| / a^2",
        explanation_template=(
            "For two identical source charges q at two vertices of an equilateral triangle of side length a, "
            "the resultant electric field at the remaining vertex is E_net = sqrt(3) * k * |q| / a^2."
        ),
        keywords=("equilateral", "triangle", "two identical charges", "remaining vertex", "electric field", "resultant"),
        variables={"E_net": "electric_field", "q": "charge", "a": "length"},
        conditions=(
            "Two identical source charges occupy two vertices of an equilateral triangle.",
            "Caclulate electric field at the remaining vertex.",
        ),
        common_mistakes=("Do not confuse with force which requires a target charge.",),
        solve=lambda k: math.sqrt(3)
        * K_COULOMB
        * abs(_q(k, "charge"))
        / (_q(k, "length") ** 2),
    ),
    Formula(
        id="electric_field_two_equal_sources_right_angle",
        domain="electrostatics",
        subfield="coulomb_law",
        target="electric_field",
        required=("charge", "length"),
        output_unit="N/C",
        expression="E_net = sqrt(2) * k * |q| / a^2",
        explanation_template=(
            "For two identical source charges q at the acute vertices of a right isosceles triangle of leg length a, "
            "the resultant electric field at the right-angle vertex is E_net = sqrt(2) * k * |q| / a^2."
        ),
        keywords=("right triangle", "right angle vertex", "two identical charges", "isosceles right triangle", "electric field", "resultant"),
        variables={"E_net": "electric_field", "q": "charge", "a": "length"},
        conditions=(
            "Two identical source charges occupy the two acute vertices of a right isosceles triangle.",
            "Calculate electric field at the right-angle vertex.",
        ),
        common_mistakes=("Use sqrt(2) for perpendicular electric field vectors.",),
        solve=lambda k: math.sqrt(2)
        * K_COULOMB
        * abs(_q(k, "charge"))
        / (_q(k, "length") ** 2),
    ),
    Formula(
        id="electric_field_opposite_equal_charges_perpendicular_bisector",
        domain="electrostatics",
        subfield="coulomb_law",
        target="electric_field",
        required=("charge", "length", "length_2"),
        output_unit="N/C",
        expression="E_net = k * |q| * d / ((d/2)^2 + h^2)^(3/2)",
        explanation_template=(
            "For equal and opposite charges separated by d, at a point on the perpendicular bisector a distance h "
            "from AB, vertical field components cancel and horizontal components add."
        ),
        keywords=("opposite", "perpendicular bisector", "distance from", "line segment", "electric field", "resultant"),
        variables={"E_net": "electric_field", "q": "charge", "d": "length", "h": "length_2"},
        conditions=(
            "Two charges have equal magnitude and opposite signs.",
            "The field point lies on the perpendicular bisector of the line joining the charges.",
        ),
        common_mistakes=("Do not use the full separation as the distance to each charge; use sqrt((d/2)^2 + h^2).",),
        solve=lambda k: K_COULOMB
        * abs(_q(k, "charge"))
        * _q(k, "length")
        / (((_q(k, "length") / 2) ** 2 + (_q(k, "length_2") ** 2)) ** 1.5),
    ),
    Formula(
        id="electric_field_midpoint_between_opposite_equal_charges",
        domain="electrostatics",
        subfield="coulomb_law",
        target="electric_field",
        required=("charge", "length"),
        output_unit="N/C",
        expression="E_net = 8 * k * |q| / d^2",
        explanation_template=(
            "For two equal and opposite point charges q separated by distance d, the electric fields at the midpoint "
            "point in the same direction and add up to E_net = 2 * k * |q| / (d/2)^2 = 8 * k * |q| / d^2."
        ),
        keywords=("midpoint", "two charges", "opposite signs", "equal magnitude", "separated by", "electric field", "net"),
        variables={"E_net": "electric_field", "q": "charge", "d": "length"},
        conditions=(
            "Midpoint between two charges of equal magnitude and opposite signs.",
        ),
        common_mistakes=("Use d/2 as distance, and add the two field magnitudes together.",),
        solve=lambda k: 8
        * K_COULOMB
        * abs(_q(k, "charge"))
        / (_q(k, "length") ** 2),
    ),
    Formula(
        id="electric_field_midpoint_between_equal_charges",
        domain="electrostatics",
        subfield="coulomb_law",
        target="electric_field",
        required=("charge", "length"),
        output_unit="N/C",
        expression="E_net = 0",
        explanation_template=(
            "For two identical point charges q separated by distance d, the electric fields at the midpoint "
            "are equal in magnitude and opposite in direction, so they cancel out completely: E_net = 0."
        ),
        keywords=("midpoint", "two identical charges", "same sign", "separated by", "electric field", "net"),
        variables={"E_net": "electric_field", "q": "charge", "d": "length"},
        conditions=(
            "Midpoint between two identical charges (same sign and magnitude).",
        ),
        common_mistakes=("Do not add the magnitudes; their directions are opposite.",),
        solve=lambda k: 0 * ureg.newton / ureg.coulomb,
    ),
    Formula(
        id="deflection_angle_uniform_field",
        domain="electrostatics",
        subfield="electric_field",
        target="angle",
        required=("mass", "charge", "electric_field", "acceleration"),
        output_unit="rad",
        expression="theta = atan(q * E / (m * g))",
        explanation_template="At equilibrium, tan(theta) = qE / (mg), so the deflection angle is atan(qE/(mg)).",
        keywords=("deflection", "angle", "suspended", "string", "uniform electric field", "equilibrium"),
        variables={"theta": "angle", "q": "charge", "E": "electric_field", "m": "mass", "g": "acceleration"},
        conditions=(
            "A charged object is suspended by a string in a uniform horizontal electric field.",
            "The system is in static equilibrium.",
        ),
        common_mistakes=("Use magnitudes for q, E, m, and g when computing the angle.",),
        solve=_deflection_angle_in_uniform_field,
    ),
    Formula(
        id="relative_permittivity_from_susceptibility",
        domain="electrostatics",
        subfield="dielectrics",
        target="relative_permittivity",
        required=("electric_susceptibility",),
        output_unit="dimensionless",
        expression="epsilon_r = 1 + chi_E",
        explanation_template="Relative permittivity is epsilon_r = 1 + electric susceptibility.",
        keywords=("relative permittivity", "susceptibility", "dielectric"),
        variables={"epsilon_r": "relative_permittivity", "chi_E": "electric_susceptibility"},
        conditions=("Linear dielectric material.",),
        common_mistakes=("Relative permittivity is dimensionless.",),
        solve=lambda k: 1 * ureg.dimensionless + _q(k, "electric_susceptibility"),
    ),
    Formula(
        id="susceptibility_from_relative_permittivity",
        domain="electrostatics",
        subfield="dielectrics",
        target="electric_susceptibility",
        required=("relative_permittivity",),
        output_unit="dimensionless",
        expression="chi_E = epsilon_r - 1",
        explanation_template="Electric susceptibility is relative permittivity minus one.",
        keywords=("susceptibility", "relative permittivity", "dielectric"),
        variables={"chi_E": "electric_susceptibility", "epsilon_r": "relative_permittivity"},
        conditions=("Linear dielectric material.",),
        common_mistakes=("Subtract one from relative permittivity.",),
        solve=lambda k: _q(k, "relative_permittivity") - 1 * ureg.dimensionless,
    ),
    Formula(
        id="magnetic_field_infinite_solenoid",
        domain="electrostatics",
        subfield="magnetism",
        target="magnetic_field",
        required=("turn_density", "current"),
        output_unit="T",
        expression="B = mu_0 * n * I",
        explanation_template="Inside an ideal long solenoid, magnetic field is B = mu_0*n*I.",
        keywords=("solenoid", "magnetic field", "turns per unit length", "current"),
        variables={"B": "magnetic_field", "n": "turn_density", "I": "current"},
        conditions=("Infinitely long or sufficiently long ideal solenoid.",),
        common_mistakes=("Use turn density n in turns per meter, not total turns unless length is accounted for.",),
        solve=lambda k: MU_0 * _q(k, "turn_density") * _q(k, "current"),
    ),
    Formula(
        id="magnetic_field_solenoid_from_turns_length_current",
        domain="electrostatics",
        subfield="magnetism",
        target="magnetic_field",
        required=("turns", "length", "current"),
        output_unit="T",
        expression="B = mu_0 * N * I / l",
        explanation_template="For a long solenoid, B = mu_0 * (N/l) * I.",
        keywords=("solenoid", "magnetic field", "turns", "length", "current"),
        variables={"B": "magnetic_field", "N": "turns", "l": "length", "I": "current"},
        conditions=("Long ideal solenoid with uniformly distributed turns.",),
        common_mistakes=("Convert the solenoid length to meters before dividing.",),
        solve=lambda k: MU_0 * _q(k, "turns") * _q(k, "current") / _q(k, "length"),
    ),
    Formula(
        id="turn_density_from_turns_length",
        domain="electrostatics",
        subfield="magnetism",
        target="turn_density",
        required=("turns", "length"),
        output_unit="1 / meter",
        expression="n = N / l",
        explanation_template="Turn density is the total number of turns divided by solenoid length: n = N/l.",
        keywords=("turn density", "turns", "length", "solenoid"),
        variables={"n": "turn_density", "N": "turns", "l": "length"},
        conditions=("Turns are distributed uniformly over the solenoid length.",),
        common_mistakes=("Convert length to meters before dividing.",),
        solve=lambda k: _q(k, "turns") / _q(k, "length"),
    ),
    Formula(
        id="induced_emf_from_inductance_current_change",
        domain="electrostatics",
        subfield="electromagnetic_induction",
        target="voltage",
        required=("inductance", "current", "current_2", "time"),
        output_unit="V",
        expression="|epsilon| = L * |Delta I| / Delta t",
        explanation_template="The magnitude of induced EMF in an inductor is |epsilon| = L*|Delta I|/Delta t.",
        keywords=("induced electromotive force", "emf", "inductance", "current increases", "current decreases", "time"),
        variables={"epsilon": "voltage", "L": "inductance", "I_1": "current", "I_2": "current_2", "Delta t": "time"},
        conditions=("The current changes uniformly between the two listed current values.",),
        common_mistakes=("Report the magnitude unless the direction/sign is requested.",),
        solve=lambda k: abs(_q(k, "inductance") * (_q(k, "current") - _q(k, "current_2")) / _q(k, "time")),
    ),
    Formula(
        id="inductance_from_emf_current_change",
        domain="electrostatics",
        subfield="electromagnetic_induction",
        target="inductance",
        required=("voltage", "current", "current_2", "time"),
        output_unit="H",
        expression="L = |epsilon| * Delta t / |Delta I|",
        explanation_template="Rearranging |epsilon| = L*|Delta I|/Delta t gives L = |epsilon|*Delta t/|Delta I|.",
        keywords=("inductance", "induced electromotive force", "emf", "current increases", "current decreases", "time"),
        variables={"L": "inductance", "epsilon": "voltage", "I_1": "current", "I_2": "current_2", "Delta t": "time"},
        conditions=("The current changes uniformly between the two listed current values.",),
        common_mistakes=("Use the magnitude of the current change.",),
        solve=lambda k: abs(_q(k, "voltage") * _q(k, "time") / (_q(k, "current") - _q(k, "current_2"))),
    ),
    Formula(
        id="induced_emf_from_flux_change",
        domain="electrostatics",
        subfield="electromagnetic_induction",
        target="voltage",
        required=("magnetic_flux", "time"),
        output_unit="V",
        expression="|epsilon| = |Delta Phi| / Delta t",
        explanation_template="Faraday's law gives average induced EMF magnitude as |epsilon| = |Delta Phi|/Delta t.",
        keywords=("magnetic flux", "decreases", "average induced electromotive force", "emf", "time"),
        variables={"epsilon": "voltage", "Phi": "magnetic_flux", "t": "time"},
        conditions=("The flux changes uniformly from the listed flux to zero, or by the listed amount.",),
        common_mistakes=("Use magnetic flux in webers and time in seconds.",),
        solve=lambda k: abs(_q(k, "magnetic_flux") / _q(k, "time")),
    ),
    Formula(
        id="magnetic_flux_from_field_area",
        domain="electrostatics",
        subfield="magnetism",
        target="magnetic_flux",
        required=("magnetic_field", "area"),
        output_unit="Wb",
        expression="Phi = B * S",
        explanation_template="Magnetic flux through one turn is Phi = B*S when the field is normal to the area.",
        keywords=("magnetic flux", "magnetic field", "flux density", "cross-sectional area", "one turn"),
        variables={"Phi": "magnetic_flux", "B": "magnetic_field", "S": "area"},
        conditions=("The magnetic field is approximately uniform and perpendicular to the cross-sectional area.",),
        common_mistakes=("Convert cm^2 to m^2 before multiplying.",),
        solve=lambda k: _q(k, "magnetic_field") * _q(k, "area"),
    ),
    Formula(
        id="magnetic_flux_solenoid_from_turn_density_current_area",
        domain="electrostatics",
        subfield="magnetism",
        target="magnetic_flux",
        required=("turn_density", "current", "area"),
        output_unit="Wb",
        expression="Phi = mu_0 * n * I * S",
        explanation_template="For a long solenoid, B = mu_0*n*I and flux through one turn is Phi = B*S.",
        keywords=("magnetic flux", "one turn", "solenoid", "turn density", "current", "cross-sectional area"),
        variables={"Phi": "magnetic_flux", "n": "turn_density", "I": "current", "S": "area"},
        conditions=("Long ideal solenoid with uniform field through the cross-section.",),
        common_mistakes=("Use the area in square meters.",),
        solve=lambda k: MU_0 * _q(k, "turn_density") * _q(k, "current") * _q(k, "area"),
    ),
    Formula(
        id="magnetic_flux_solenoid_from_turns_length_current_area",
        domain="electrostatics",
        subfield="magnetism",
        target="magnetic_flux",
        required=("turns", "length", "current", "area"),
        output_unit="Wb",
        expression="Phi = mu_0 * N * I * S / l",
        explanation_template="For a long solenoid, flux through one turn is Phi = B*S and B = mu_0*N*I/l.",
        keywords=("magnetic flux", "solenoid", "turns", "length", "current", "area"),
        variables={"Phi": "magnetic_flux", "N": "turns", "l": "length", "I": "current", "S": "area"},
        conditions=("Long ideal solenoid with uniform field through the cross-section.",),
        common_mistakes=("Use the area in square meters and the length in meters.",),
        solve=lambda k: MU_0 * _q(k, "turns") * _q(k, "current") * _q(k, "area") / _q(k, "length"),
    ),
    Formula(
        id="flux_linkage_from_turns_flux",
        domain="electrostatics",
        subfield="magnetism",
        target="magnetic_flux",
        required=("turns", "magnetic_flux"),
        output_unit="Wb",
        expression="Psi = N * Phi",
        explanation_template="Flux linkage is the number of turns times flux per turn: Psi = N*Phi.",
        keywords=("flux linkage", "turns", "magnetic flux"),
        variables={"Psi": "magnetic_flux", "N": "turns", "Phi": "magnetic_flux_2"},
        conditions=("Flux per turn is the same for each turn.",),
        common_mistakes=("Multiply flux by the total number of turns.",),
        solve=lambda k: _q(k, "turns") * _q(k, "magnetic_flux"),
    ),
    Formula(
        id="magnetic_energy_density_from_field",
        domain="electrostatics",
        subfield="magnetism",
        target="energy_density",
        required=("magnetic_field",),
        output_unit="J / m^3",
        expression="u_B = B^2 / (2*mu_0)",
        explanation_template="Magnetic energy density is u_B = B^2/(2*mu_0).",
        keywords=("energy density", "magnetic field energy density", "magnetic field"),
        variables={"u_B": "energy_density", "B": "magnetic_field"},
        conditions=("Magnetic field is in vacuum or air where mu_0 applies.",),
        common_mistakes=("Square the magnetic field before dividing by 2*mu_0.",),
        solve=lambda k: (_q(k, "magnetic_field") ** 2) / (2 * MU_0),
    ),
    Formula(
        id="magnetic_energy_from_solenoid_geometry",
        domain="electrostatics",
        subfield="magnetism",
        target="energy",
        required=("turns", "length", "area", "current"),
        output_unit="J",
        expression="W = 1/2 * mu_0 * N^2 * S * I^2 / l",
        explanation_template="For a long solenoid, W = 1/2 * L * I^2 with L = mu_0*N^2*S/l.",
        keywords=("magnetic energy", "solenoid", "turns", "length", "area", "current"),
        variables={"W": "energy", "N": "turns", "l": "length", "S": "area", "I": "current"},
        conditions=("Long ideal solenoid with uniform cross-sectional area.",),
        common_mistakes=("Use meters squared for area and meters for length.",),
        solve=lambda k: 0.5 * MU_0 * (_q(k, "turns") ** 2) * _q(k, "area") * (_q(k, "current") ** 2) / _q(k, "length"),
    ),
    Formula(
        id="inductive_reactance",
        domain="circuits",
        subfield="ac_circuits",
        target="impedance",
        required=("inductance", "frequency"),
        output_unit="ohm",
        expression="Z_L = 2*pi*f*L",
        explanation_template="Inductive reactance is Z_L = 2*pi*f*L.",
        keywords=("inductive reactance", "frequency", "inductance"),
        variables={"Z_L": "impedance", "f": "frequency", "L": "inductance"},
        conditions=("Sinusoidal steady-state AC circuit.",),
        common_mistakes=("Use frequency in hertz, not angular frequency unless already given.",),
        solve=lambda k: 2 * math.pi * _q(k, "frequency") * _q(k, "inductance"),
    ),
    Formula(
        id="capacitive_reactance",
        domain="circuits",
        subfield="ac_circuits",
        target="impedance",
        required=("capacitance", "frequency"),
        output_unit="ohm",
        expression="Z_C = 1 / (2*pi*f*C)",
        explanation_template="Capacitive reactance is Z_C = 1/(2*pi*f*C).",
        keywords=("capacitive reactance", "frequency", "capacitance"),
        variables={"Z_C": "impedance", "f": "frequency", "C": "capacitance"},
        conditions=("Sinusoidal steady-state AC circuit.",),
        common_mistakes=("Capacitive reactance decreases as frequency or capacitance increases.",),
        solve=lambda k: 1 / (2 * math.pi * _q(k, "frequency") * _q(k, "capacitance")),
    ),
    Formula(
        id="series_rlc_impedance",
        domain="circuits",
        subfield="ac_circuits",
        target="impedance",
        required=("resistance", "inductance", "capacitance", "frequency"),
        output_unit="ohm",
        expression="Z = sqrt(R^2 + (2*pi*f*L - 1/(2*pi*f*C))^2)",
        explanation_template="Series RLC impedance is Z = sqrt(R^2 + (Z_L - Z_C)^2).",
        keywords=("rlc", "series", "total impedance", "impedance", "frequency", "resistance", "inductance", "capacitance"),
        variables={"Z": "impedance", "R": "resistance", "L": "inductance", "C": "capacitance", "f": "frequency"},
        conditions=("Series RLC circuit in sinusoidal steady state.",),
        common_mistakes=("Subtract capacitive reactance from inductive reactance before squaring.",),
        solve=lambda k: (
            (_q(k, "resistance") ** 2)
            + (
                2 * math.pi * _q(k, "frequency") * _q(k, "inductance")
                - 1 / (2 * math.pi * _q(k, "frequency") * _q(k, "capacitance"))
            )
            ** 2
        )
        ** 0.5,
    ),
    Formula(
        id="speed_of_light_from_vacuum_constants",
        domain="electrostatics",
        subfield="electromagnetic_waves",
        target="speed",
        required=("permittivity", "permeability"),
        output_unit="m/s",
        expression="c = 1 / sqrt(epsilon_0 * mu_0)",
        explanation_template="The speed of light in vacuum follows c = 1/sqrt(epsilon_0*mu_0).",
        keywords=("speed of light", "permittivity", "permeability", "electromagnetic waves"),
        variables={"c": "speed", "epsilon_0": "permittivity", "mu_0": "permeability"},
        conditions=("Vacuum constants are used.",),
        common_mistakes=("Take the square root of the product epsilon_0*mu_0.",),
        solve=lambda k: 1 / ((_q(k, "permittivity") * _q(k, "permeability")) ** 0.5),
    ),
    Formula(
        id="speed_em_wave_in_medium",
        domain="electrostatics",
        subfield="electromagnetic_waves",
        target="speed",
        required=("permittivity", "permeability"),
        output_unit="m/s",
        expression="v = 1 / sqrt(epsilon * mu)",
        explanation_template="In a material medium, electromagnetic wave speed is v = 1/sqrt(epsilon*mu).",
        keywords=("speed", "electromagnetic wave", "medium", "permittivity", "permeability"),
        variables={"v": "speed", "epsilon": "permittivity", "mu": "permeability"},
        conditions=("Material permittivity and permeability are absolute values, not relative factors.",),
        common_mistakes=("If given relative values, multiply by epsilon_0 and mu_0 first.",),
        solve=lambda k: 1 / ((_q(k, "permittivity") * _q(k, "permeability")) ** 0.5),
    ),
    Formula(
        id="photon_momentum_from_energy",
        domain="electrostatics",
        subfield="electromagnetic_waves",
        target="momentum",
        required=("energy",),
        output_unit="kg * m / s",
        expression="p = E / c",
        explanation_template="Photon momentum is p = E/c.",
        keywords=("photon", "momentum", "energy", "speed of light"),
        variables={"p": "momentum", "E": "energy", "c": "speed"},
        conditions=("Photon or electromagnetic radiation in vacuum unless otherwise stated.",),
        common_mistakes=("Divide energy by the speed of light.",),
        solve=lambda k: _q(k, "energy") / C_LIGHT,
    ),
    Formula(
        id="flux_density_from_luminosity_distance",
        domain="electrostatics",
        subfield="radiation",
        target="flux_density",
        required=("power", "length"),
        output_unit="W / m^2",
        expression="f = L / (4*pi*d^2)",
        explanation_template="Flux density from an isotropic source is luminosity divided by spherical area.",
        keywords=("flux density", "luminosity", "distance", "inverse square"),
        variables={"f": "flux_density", "L": "power", "d": "length"},
        conditions=("Isotropic emission into free space.",),
        common_mistakes=("Use distance squared in the denominator.",),
        solve=lambda k: _q(k, "power") / (4 * math.pi * (_q(k, "length") ** 2)),
    ),
    Formula(
        id="em_wave_intensity_from_field_amplitudes",
        domain="electrostatics",
        subfield="electromagnetic_waves",
        target="intensity",
        required=("electric_field", "magnetic_field"),
        output_unit="W / m^2",
        expression="I = E_max * B_max / (2*mu_0)",
        explanation_template="The average intensity of an EM wave is I = E_max*B_max/(2 mu_0).",
        keywords=("intensity", "electromagnetic wave", "electric field", "magnetic field", "poynting"),
        variables={"I": "intensity", "E_max": "electric_field", "B_max": "magnetic_field"},
        conditions=("E and B are peak field amplitudes of a plane electromagnetic wave.",),
        common_mistakes=("For peak amplitudes include the factor 1/2.",),
        solve=lambda k: _q(k, "electric_field") * _q(k, "magnetic_field") / (2 * MU_0),
    ),
    Formula(
        id="capacitance_from_energy_voltage",
        domain="capacitance",
        subfield="capacitor_energy",
        target="capacitance",
        required=("energy", "voltage"),
        output_unit="F",
        expression="C = 2W / U^2",
        explanation_template="Rearranging the capacitor energy formula gives C = 2W / U^2.",
        keywords=("capacitance", "capacitor", "energy", "voltage"),
        variables={"C": "capacitance", "W": "energy", "U": "voltage"},
        conditions=("Energy and voltage refer to the same capacitor.",),
        common_mistakes=("Square the voltage before dividing.",),
        solve=lambda k: (2 * _q(k, "energy")) / (_q(k, "voltage") ** 2),
    ),
    Formula(
        id="series_capacitance_two",
        domain="capacitance",
        subfield="capacitor_networks",
        target="capacitance",
        required=("capacitance", "capacitance_2"),
        output_unit="F",
        expression="C_eq = C1 * C2 / (C1 + C2)",
        explanation_template="For two capacitors in series, C_eq = C1C2/(C1+C2).",
        keywords=("series", "equivalent capacitance", "capacitors"),
        variables={"C_eq": "capacitance", "C1": "capacitance", "C2": "capacitance_2"},
        conditions=("Two capacitors connected in series.",),
        common_mistakes=("Series capacitors use the reciprocal rule.",),
        solve=lambda k: (_q(k, "capacitance") * _q(k, "capacitance_2"))
        / (_q(k, "capacitance") + _q(k, "capacitance_2")),
    ),
    Formula(
        id="parallel_capacitance",
        domain="capacitance",
        subfield="capacitor_networks",
        target="capacitance",
        required=("capacitance", "capacitance_2"),
        output_unit="F",
        expression="C_eq = C1 + C2",
        explanation_template="For two capacitors in parallel, equivalent capacitance is C_eq = C1 + C2.",
        keywords=("parallel", "equivalent capacitance", "capacitors"),
        variables={"C_eq": "capacitance", "C1": "capacitance", "C2": "capacitance_2"},
        conditions=("Two capacitors connected in parallel.",),
        common_mistakes=("Do not use the resistor parallel formula for parallel capacitors.",),
        solve=lambda k: _q(k, "capacitance") + _q(k, "capacitance_2"),
    ),
    Formula(
        id="series_capacitance_three",
        domain="capacitance",
        subfield="capacitor_networks",
        target="capacitance",
        required=("capacitance", "capacitance_2", "capacitance_3"),
        output_unit="F",
        expression="1/C_eq = 1/C1 + 1/C2 + 1/C3",
        explanation_template="For three capacitors in series, reciprocal equivalent capacitance is the sum of reciprocals.",
        keywords=("series", "equivalent capacitance", "capacitors", "three"),
        variables={"C_eq": "capacitance", "C1": "capacitance", "C2": "capacitance_2", "C3": "capacitance_3"},
        conditions=("Three capacitors connected in series.",),
        common_mistakes=("Series capacitors use reciprocal addition.",),
        solve=lambda k: 1
        / (1 / _q(k, "capacitance") + 1 / _q(k, "capacitance_2") + 1 / _q(k, "capacitance_3")),
    ),
    Formula(
        id="parallel_capacitance_three",
        domain="capacitance",
        subfield="capacitor_networks",
        target="capacitance",
        required=("capacitance", "capacitance_2", "capacitance_3"),
        output_unit="F",
        expression="C_eq = C1 + C2 + C3",
        explanation_template="For three capacitors in parallel, equivalent capacitance is C_eq = C1 + C2 + C3.",
        keywords=("parallel", "equivalent capacitance", "capacitors", "three"),
        variables={"C_eq": "capacitance", "C1": "capacitance", "C2": "capacitance_2", "C3": "capacitance_3"},
        conditions=("Three capacitors connected in parallel.",),
        common_mistakes=("Parallel capacitors add directly.",),
        solve=lambda k: _q(k, "capacitance") + _q(k, "capacitance_2") + _q(k, "capacitance_3"),
    ),
    Formula(
        id="series_voltage_two",
        domain="circuits",
        subfield="dc_circuits",
        target="voltage",
        required=("voltage", "voltage_2"),
        output_unit="V",
        expression="U_total = U1 + U2",
        explanation_template="For components in series, total potential difference is the sum of component voltages.",
        keywords=("series", "potential difference", "voltage", "components"),
        variables={"U_total": "voltage", "U1": "voltage", "U2": "voltage_2"},
        conditions=("Two components connected in series.",),
        common_mistakes=("Series voltages add directly.",),
        solve=lambda k: _q(k, "voltage") + _q(k, "voltage_2"),
    ),
    Formula(
        id="series_voltage_three",
        domain="circuits",
        subfield="dc_circuits",
        target="voltage",
        required=("voltage", "voltage_2", "voltage_3"),
        output_unit="V",
        expression="U_total = U1 + U2 + U3",
        explanation_template="For three series components, total potential difference is U1 + U2 + U3.",
        keywords=("series", "potential difference", "voltage", "three components"),
        variables={"U_total": "voltage", "U1": "voltage", "U2": "voltage_2", "U3": "voltage_3"},
        conditions=("Three components connected in series.",),
        common_mistakes=("Series voltages add directly.",),
        solve=lambda k: _q(k, "voltage") + _q(k, "voltage_2") + _q(k, "voltage_3"),
    ),
    Formula(
        id="parallel_plate_capacitance_air",
        domain="capacitance",
        subfield="capacitor_basics",
        target="capacitance",
        required=("area", "length"),
        output_unit="F",
        expression="C = epsilon_0 * A / d",
        explanation_template="For an air/vacuum parallel-plate capacitor, capacitance is C = epsilon_0 A/d.",
        keywords=("parallel plate", "capacitance", "area", "separation", "distance"),
        variables={"C": "capacitance", "A": "area", "d": "length"},
        conditions=("Air or vacuum between large parallel plates, neglecting edge effects.",),
        common_mistakes=("Use plate separation d in the denominator.",),
        solve=lambda k: (8.8541878128e-12 * ureg.farad / ureg.meter) * _q(k, "area") / _q(k, "length"),
    ),
    Formula(
        id="mass_from_density_volume",
        domain="mechanics",
        subfield="material_properties",
        target="mass",
        required=("density", "volume"),
        output_unit="kg",
        expression="m = rho * V",
        explanation_template="Mass is density times volume: m = rho*V.",
        keywords=("mass", "density", "volume", "water"),
        variables={"m": "mass", "rho": "density", "V": "volume"},
        conditions=("Density and volume refer to the same material.",),
        common_mistakes=("Convert liters to cubic meters when density is in kg/m^3.",),
        solve=lambda k: _q(k, "density") * _q(k, "volume"),
    ),
    Formula(
        id="density_from_mass_volume",
        domain="mechanics",
        subfield="material_properties",
        target="density",
        required=("mass", "volume"),
        output_unit="kg / m^3",
        expression="rho = m / V",
        explanation_template="Density is mass divided by volume.",
        keywords=("density", "mass", "volume"),
        variables={"rho": "density", "m": "mass", "V": "volume"},
        conditions=("Mass and volume refer to the same material.",),
        common_mistakes=("Divide mass by volume.",),
        solve=lambda k: _q(k, "mass") / _q(k, "volume"),
    ),
    Formula(
        id="volume_from_mass_density",
        domain="mechanics",
        subfield="material_properties",
        target="volume",
        required=("mass", "density"),
        output_unit="m^3",
        expression="V = m / rho",
        explanation_template="Volume is mass divided by density.",
        keywords=("volume", "mass", "density"),
        variables={"V": "volume", "m": "mass", "rho": "density"},
        conditions=("Mass and density refer to the same material.",),
        common_mistakes=("Divide mass by density.",),
        solve=lambda k: _q(k, "mass") / _q(k, "density"),
    ),
    Formula(
        id="rectangle_area",
        domain="mechanics",
        subfield="geometry",
        target="area",
        required=("length", "length_2"),
        output_unit="m^2",
        expression="A = l * w",
        explanation_template="The area of a rectangle is length times width.",
        keywords=("rectangle", "rectangular", "area", "length", "width"),
        variables={"A": "area", "l": "length", "w": "length_2"},
        conditions=("The shape is a rectangle or rectangular face.",),
        common_mistakes=("Use area units, not perimeter units.",),
        solve=lambda k: _q(k, "length") * _q(k, "length_2"),
    ),
    Formula(
        id="triangle_area_base_height",
        domain="mechanics",
        subfield="geometry",
        target="area",
        required=("length", "length_2"),
        output_unit="m^2",
        expression="A = 1/2 * b * h",
        explanation_template="The area of a triangle is one half times base times height.",
        keywords=("triangle", "area", "base", "height"),
        variables={"A": "area", "b": "length", "h": "length_2"},
        conditions=("The two lengths are the triangle base and the perpendicular height.",),
        common_mistakes=("Remember the factor 1/2.",),
        solve=lambda k: 0.5 * _q(k, "length") * _q(k, "length_2"),
    ),
    Formula(
        id="circle_area_from_radius",
        domain="mechanics",
        subfield="geometry",
        target="area",
        required=("length",),
        output_unit="m^2",
        expression="A = pi * r^2",
        explanation_template="The area of a circle is pi times the radius squared.",
        keywords=("circle", "circular", "area", "radius"),
        variables={"A": "area", "r": "length"},
        conditions=("The given length is the radius of a circle.",),
        common_mistakes=("Square the radius; do not use diameter unless it is first halved.",),
        solve=lambda k: math.pi * (_q(k, "length") ** 2),
    ),
    Formula(
        id="sphere_surface_area_from_radius",
        domain="mechanics",
        subfield="geometry",
        target="area",
        required=("length",),
        output_unit="m^2",
        expression="S = 4 * pi * r^2",
        explanation_template="The surface area of a sphere is 4*pi*r^2.",
        keywords=("sphere", "spherical", "surface area", "radius"),
        variables={"S": "area", "r": "length"},
        conditions=("The requested quantity is the surface area of a sphere.",),
        common_mistakes=("Do not use the circle area formula for sphere surface area.",),
        solve=lambda k: 4 * math.pi * (_q(k, "length") ** 2),
    ),
    Formula(
        id="rectangular_prism_volume",
        domain="mechanics",
        subfield="geometry",
        target="volume",
        required=("length", "length_2", "length_3"),
        output_unit="m^3",
        expression="V = l * w * h",
        explanation_template="The volume of a rectangular prism is length times width times height.",
        keywords=("rectangular prism", "cuboid", "box", "volume", "length", "width", "height"),
        variables={"V": "volume", "l": "length", "w": "length_2", "h": "length_3"},
        conditions=("The solid is a rectangular prism, cuboid, or box.",),
        common_mistakes=("Use three perpendicular lengths.",),
        solve=lambda k: _q(k, "length") * _q(k, "length_2") * _q(k, "length_3"),
    ),
    Formula(
        id="cylinder_volume_from_radius_height",
        domain="mechanics",
        subfield="geometry",
        target="volume",
        required=("length", "length_2"),
        output_unit="m^3",
        expression="V = pi * r^2 * h",
        explanation_template="The volume of a cylinder is pi*r^2*h.",
        keywords=("cylinder", "cylindrical", "volume", "radius", "height"),
        variables={"V": "volume", "r": "length", "h": "length_2"},
        conditions=("The two lengths are the cylinder radius and height.",),
        common_mistakes=("Square the radius, not the height.",),
        solve=lambda k: math.pi * (_q(k, "length") ** 2) * _q(k, "length_2"),
    ),
    Formula(
        id="sphere_volume_from_radius",
        domain="mechanics",
        subfield="geometry",
        target="volume",
        required=("length",),
        output_unit="m^3",
        expression="V = 4/3 * pi * r^3",
        explanation_template="The volume of a sphere is 4/3*pi*r^3.",
        keywords=("sphere", "spherical", "volume", "radius"),
        variables={"V": "volume", "r": "length"},
        conditions=("The given length is the sphere radius.",),
        common_mistakes=("Cube the radius and include the factor 4/3.",),
        solve=lambda k: (4 / 3) * math.pi * (_q(k, "length") ** 3),
    ),
    Formula(
        id="pythagorean_hypotenuse",
        domain="mechanics",
        subfield="geometry",
        target="length",
        required=("length", "length_2"),
        output_unit="m",
        expression="c = sqrt(a^2 + b^2)",
        explanation_template="In a right triangle, the hypotenuse is sqrt(a^2+b^2).",
        keywords=("right triangle", "right-angled", "hypotenuse", "pythagorean", "legs"),
        variables={"c": "length", "a": "length", "b": "length_2"},
        conditions=("The two known lengths are perpendicular legs of a right triangle.",),
        common_mistakes=("Use this only for the hypotenuse, not for a missing leg.",),
        solve=lambda k: (_q(k, "length") ** 2 + _q(k, "length_2") ** 2) ** 0.5,
    ),
    Formula(
        id="pythagorean_leg",
        domain="mechanics",
        subfield="geometry",
        target="length",
        required=("length", "length_2"),
        output_unit="m",
        expression="a = sqrt(c^2 - b^2)",
        explanation_template="In a right triangle, a missing leg is sqrt(c^2-b^2).",
        keywords=("right triangle", "right-angled", "missing leg", "pythagorean", "hypotenuse"),
        variables={"a": "length", "c": "length", "b": "length_2"},
        conditions=("The first known length is the hypotenuse and the second is the other leg.",),
        common_mistakes=("Subtract the squared known leg from the squared hypotenuse.",),
        solve=_pythagorean_leg,
    ),
    Formula(
        id="pressure_from_force_area",
        domain="mechanics",
        subfield="pressure",
        target="pressure",
        required=("force", "area"),
        output_unit="Pa",
        expression="p = F / S",
        explanation_template="Pressure is force divided by contact area.",
        keywords=("pressure", "force", "area", "contact area"),
        variables={"p": "pressure", "F": "force", "S": "area"},
        conditions=("Force is normal to the area.",),
        common_mistakes=("Use total contact area when multiple contact patches are involved.",),
        solve=lambda k: _q(k, "force") / _q(k, "area"),
    ),
    Formula(
        id="force_from_pressure_area",
        domain="mechanics",
        subfield="pressure",
        target="force",
        required=("pressure", "area"),
        output_unit="N",
        expression="F = p * S",
        explanation_template="Force from pressure over area is F = p*S.",
        keywords=("force", "pressure", "area", "piston"),
        variables={"F": "force", "p": "pressure", "S": "area"},
        conditions=("Pressure is uniform over the area.",),
        common_mistakes=("Multiply pressure by area.",),
        solve=lambda k: _q(k, "pressure") * _q(k, "area"),
    ),
    Formula(
        id="work_from_pressure_volume",
        domain="mechanics",
        subfield="pressure_work",
        target="energy",
        required=("pressure", "volume"),
        output_unit="J",
        expression="W = p * V",
        explanation_template="For constant pressure expansion, work is W = p*DeltaV.",
        keywords=("work", "pressure", "volume", "gas", "piston"),
        variables={"W": "energy", "p": "pressure", "V": "volume"},
        conditions=("Pressure is constant and volume is the volume change.",),
        common_mistakes=("Use volume change, not necessarily total cylinder volume unless specified.",),
        solve=lambda k: _q(k, "pressure") * _q(k, "volume"),
    ),
    Formula(
        id="wavelength_from_speed_frequency",
        domain="waves",
        subfield="wave_basics",
        target="length",
        required=("speed", "frequency"),
        output_unit="m",
        expression="lambda = v / f",
        explanation_template="Wavelength is wave speed divided by frequency.",
        keywords=("wavelength", "frequency", "speed of light", "wave"),
        variables={"lambda": "length", "v": "speed", "f": "frequency"},
        conditions=("Wave speed and frequency are in the same medium.",),
        common_mistakes=("Higher frequency gives shorter wavelength.",),
        solve=lambda k: _q(k, "speed") / _q(k, "frequency"),
    ),
    Formula(
        id="frequency_from_speed_wavelength",
        domain="waves",
        subfield="wave_basics",
        target="frequency",
        required=("speed", "length"),
        output_unit="Hz",
        expression="f = v / lambda",
        explanation_template="Frequency is wave speed divided by wavelength.",
        keywords=("frequency", "wavelength", "speed of light", "wave"),
        variables={"f": "frequency", "v": "speed", "lambda": "length"},
        conditions=("Wave speed and wavelength are in the same medium.",),
        common_mistakes=("Divide speed by wavelength.",),
        solve=lambda k: _q(k, "speed") / _q(k, "length"),
    ),
    Formula(
        id="wave_speed_from_frequency_wavelength",
        domain="waves",
        subfield="wave_basics",
        target="speed",
        required=("frequency", "length"),
        output_unit="m/s",
        expression="v = f * lambda",
        explanation_template="Wave speed is frequency times wavelength.",
        keywords=("speed", "frequency", "wavelength", "wave"),
        variables={"v": "speed", "f": "frequency", "lambda": "length"},
        conditions=("Frequency and wavelength are in the same medium.",),
        common_mistakes=("Multiply frequency by wavelength.",),
        solve=lambda k: _q(k, "frequency") * _q(k, "length"),
    ),
    Formula(
        id="electrical_energy_from_voltage_current_time",
        domain="circuits",
        subfield="dc_power",
        target="energy",
        required=("voltage", "current", "time"),
        output_unit="J",
        expression="W = U * I * t",
        explanation_template="Electrical energy transferred is W = U*I*t.",
        keywords=("electrical energy", "voltage", "current", "time", "heat produced"),
        variables={"W": "energy", "U": "voltage", "I": "current", "t": "time"},
        conditions=("Voltage and current refer to the same component over the time interval.",),
        common_mistakes=("Convert minutes or hours to seconds when using watts.",),
        solve=lambda k: _q(k, "voltage") * _q(k, "current") * _q(k, "time"),
    ),
    Formula(
        id="joule_heating_from_current_resistance_time",
        domain="circuits",
        subfield="dc_power",
        target="energy",
        required=("current", "resistance", "time"),
        output_unit="J",
        expression="Q = I^2 * R * t",
        explanation_template="Joule heating in a resistor is Q = I^2*R*t.",
        keywords=("joule heating", "heat produced", "current", "resistance", "time"),
        variables={"Q": "energy", "I": "current", "R": "resistance", "t": "time"},
        conditions=("Current is through the resistor for the given time.",),
        common_mistakes=("Square the current, not the resistance.",),
        solve=lambda k: (_q(k, "current") ** 2) * _q(k, "resistance") * _q(k, "time"),
    ),
    Formula(
        id="electrical_energy_from_voltage_charge",
        domain="circuits",
        subfield="dc_power",
        target="energy",
        required=("voltage", "charge"),
        output_unit="J",
        expression="W = U * Q",
        explanation_template="Electrical energy transferred by charge through voltage is W = U*Q.",
        keywords=("electrical energy", "voltage", "charge"),
        variables={"W": "energy", "U": "voltage", "Q": "charge"},
        conditions=("Charge moves through the given potential difference.",),
        common_mistakes=("Multiply voltage by charge.",),
        solve=lambda k: _q(k, "voltage") * _q(k, "charge"),
    ),
    Formula(
        id="stefan_boltzmann_radiated_power",
        domain="electrostatics",
        subfield="radiation",
        target="power",
        required=("area", "emissivity", "temperature"),
        output_unit="W",
        expression="P = A * epsilon * sigma * T^4",
        explanation_template="The Stefan-Boltzmann law gives radiated power P = A*epsilon*sigma*T^4.",
        keywords=("stefan boltzmann", "radiated power", "emissivity", "temperature", "area"),
        variables={"P": "power", "A": "area", "epsilon": "emissivity", "T": "temperature"},
        conditions=("Temperature is absolute temperature in kelvin.",),
        common_mistakes=("Use kelvin, not Celsius, in T^4.",),
        solve=lambda k: _q(k, "area") * _q(k, "emissivity") * STEFAN_BOLTZMANN * (_q(k, "temperature") ** 4),
    ),
    Formula(
        id="ideal_transformer_voltage_secondary",
        domain="circuits",
        subfield="transformers",
        target="voltage",
        required=("voltage", "turns_primary", "turns_secondary"),
        output_unit="V",
        expression="V_s = V_p * N_s / N_p",
        explanation_template="An ideal transformer has Vp/Vs = Np/Ns, so Vs = Vp*Ns/Np.",
        keywords=("transformer", "secondary voltage", "primary voltage", "turns"),
        variables={"V_s": "voltage", "V_p": "voltage", "N_p": "turns_primary", "N_s": "turns_secondary"},
        conditions=("Ideal transformer with negligible losses.",),
        common_mistakes=("Use the same primary/secondary orientation for voltage and turns.",),
        solve=lambda k: _q(k, "voltage") * _q(k, "turns_secondary") / _q(k, "turns_primary"),
    ),
    Formula(
        id="ideal_transformer_voltage_primary",
        domain="circuits",
        subfield="transformers",
        target="voltage",
        required=("voltage_2", "turns_primary", "turns_secondary"),
        output_unit="V",
        expression="V_p = V_s * N_p / N_s",
        explanation_template="An ideal transformer has Vp/Vs = Np/Ns, so Vp = Vs*Np/Ns.",
        keywords=("transformer", "primary voltage", "secondary voltage", "turns"),
        variables={"V_p": "voltage", "V_s": "voltage_2", "N_p": "turns_primary", "N_s": "turns_secondary"},
        conditions=("Ideal transformer with negligible losses.",),
        common_mistakes=("Do not invert the turns ratio.",),
        solve=lambda k: _q(k, "voltage_2") * _q(k, "turns_primary") / _q(k, "turns_secondary"),
    ),
    Formula(
        id="ideal_transformer_secondary_current",
        domain="circuits",
        subfield="transformers",
        target="current",
        required=("current", "voltage", "voltage_2"),
        output_unit="A",
        expression="I_s = I_p * V_p / V_s",
        explanation_template="For an ideal transformer, input power equals output power: Ip*Vp = Is*Vs.",
        keywords=("transformer", "secondary current", "primary current", "power"),
        variables={"I_s": "current", "I_p": "current", "V_p": "voltage", "V_s": "voltage_2"},
        conditions=("Ideal transformer with conserved electrical power.",),
        common_mistakes=("Current ratio is inverse to voltage ratio in an ideal transformer.",),
        solve=lambda k: _q(k, "current") * _q(k, "voltage") / _q(k, "voltage_2"),
    ),
    Formula(
        id="resistivity_from_resistance_area_length",
        domain="circuits",
        subfield="material_properties",
        target="resistivity",
        required=("resistance", "area", "length"),
        output_unit="ohm * meter",
        expression="rho = R * A / l",
        explanation_template="Electrical resistivity is rho = R * A / l.",
        keywords=("resistivity", "resistance", "area", "length", "material"),
        variables={"rho": "resistivity", "R": "resistance", "A": "area", "l": "length"},
        conditions=("Resistance, area, and length refer to the same sample of material.",),
        common_mistakes=("Use area in square meters and length in meters.",),
        solve=lambda k: _q(k, "resistance") * _q(k, "area") / _q(k, "length"),
    ),
    Formula(
        id="resistance_from_resistivity_length_area",
        domain="circuits",
        subfield="material_properties",
        target="resistance",
        required=("resistivity", "length", "area"),
        output_unit="ohm",
        expression="R = rho * l / A",
        explanation_template="Resistance of a uniform wire is R = rho * l / A.",
        keywords=("resistance", "resistivity", "wire", "length", "area"),
        variables={"R": "resistance", "rho": "resistivity", "l": "length", "A": "area"},
        conditions=("Uniform material with constant cross-sectional area.",),
        common_mistakes=("Resistance increases with length and decreases with area.",),
        solve=lambda k: _q(k, "resistivity") * _q(k, "length") / _q(k, "area"),
    ),
)


def retrieve_formulas(
    question: str,
    target: str | None,
    known: dict[str, object],
    preferred_formula_ids: tuple[str, ...] = (),
) -> list[Formula]:
    lower = question.lower()
    candidates = [
        formula
        for formula in FORMULAS
        if (target is None or formula.target == target)
        and all(required in known for required in formula.required)
        and _formula_condition_matches(formula, lower)
    ]
    preferred = {formula_id: index for index, formula_id in enumerate(preferred_formula_ids)}
    return sorted(
        candidates,
        key=lambda formula: _formula_score(formula, question, preferred),
        reverse=True,
    )


def formula_summary(formula: Formula) -> dict[str, object]:
    return {
        "id": formula.id,
        "domain": formula.domain,
        "subfield": formula.subfield,
        "target": formula.target,
        "required": formula.required,
        "output_unit": formula.output_unit,
        "expression": formula.expression,
        "variables": formula.variables,
        "conditions": formula.conditions,
        "common_mistakes": formula.common_mistakes,
    }


def _formula_score(
    formula: Formula,
    question: str,
    preferred: dict[str, int] | None = None,
) -> tuple[int, int]:
    lower = question.lower()
    llm_bonus = 0
    if preferred and formula.id in preferred:
        llm_bonus = 1000 - preferred[formula.id]
    keyword_score = sum(1 for keyword in formula.keywords if keyword in lower)
    return (llm_bonus, keyword_score)


def _formula_condition_matches(formula: Formula, lower_question: str) -> bool:
    if formula.id == "rectangle_area":
        return any(term in lower_question for term in ("rectangle", "rectangular"))
    if formula.id == "triangle_area_base_height":
        return "triangle" in lower_question and "height" in lower_question
    if formula.id == "circle_area_from_radius":
        return any(term in lower_question for term in ("circle", "circular")) and "area" in lower_question
    if formula.id == "sphere_surface_area_from_radius":
        return any(term in lower_question for term in ("sphere", "spherical")) and "surface area" in lower_question
    if formula.id == "rectangular_prism_volume":
        return any(term in lower_question for term in ("rectangular prism", "cuboid", "box"))
    if formula.id == "cylinder_volume_from_radius_height":
        return any(term in lower_question for term in ("cylinder", "cylindrical")) and "volume" in lower_question
    if formula.id == "sphere_volume_from_radius":
        return any(term in lower_question for term in ("sphere", "spherical")) and "volume" in lower_question
    if formula.id == "pythagorean_hypotenuse":
        return (
            ("right triangle" in lower_question or "right-angled" in lower_question)
            and ("hypotenuse" in lower_question or "diagonal" in lower_question)
        )
    if formula.id == "pythagorean_leg":
        return (
            ("right triangle" in lower_question or "right-angled" in lower_question)
            and ("missing leg" in lower_question or "other leg" in lower_question)
        )
    if formula.id == "net_force_midpoint_between_opposite_equal_charges":
        return "midpoint" in lower_question or "middle of" in lower_question
    if formula.id == "net_force_three_collinear_middle_charge":
        return "straight line" in lower_question or "collinear" in lower_question
    if formula.id in {
        "net_force_equal_coulomb_equilateral",
        "net_force_two_equal_sources_equilateral_on_target",
    }:
        return "equilateral" in lower_question
    if formula.id == "net_force_equal_charges_right_angle":
        return (
            ("isosceles right triangle" in lower_question or "identical charges" in lower_question)
            and ("right angle" in lower_question or "right-angled" in lower_question)
        )
    if formula.id == "net_force_three_charges_triangle_on_q3":
        return (
            ("q3" in lower_question or "point c" in lower_question)
            and ("ac" in lower_question or "ca" in lower_question)
            and ("bc" in lower_question or "cb" in lower_question)
        )
    if formula.id == "net_force_right_triangle_at_a_from_b_c":
        return (
            ("right-angled at a" in lower_question or "right angle at a" in lower_question)
            and "ab" in lower_question
            and "bc" in lower_question
            and ("charge at a" in lower_question or "qa" in lower_question)
        )
    if formula.id == "electric_field_two_equal_sources_right_angle":
        return (
            ("right triangle" in lower_question or "right-angle" in lower_question or "right angle" in lower_question)
            and "perpendicular bisector" not in lower_question
        )
    if formula.id == "electric_field_opposite_equal_charges_perpendicular_bisector":
        return "perpendicular bisector" in lower_question and (
            "opposite" in lower_question or "+3" in lower_question or "-3" in lower_question
        )
    if formula.id == "voltage_disconnected_capacitor_insert_dielectric":
        return "disconnected" in lower_question and "dielectric" in lower_question
    if formula.id == "voltage_connected_capacitor_insert_dielectric":
        return (
            ("still connected" in lower_question or "connected to the source" in lower_question)
            and "dielectric" in lower_question
        )
    if formula.id == "energy_disconnected_capacitor_insert_dielectric":
        return "disconnected" in lower_question and "dielectric" in lower_question
    if formula.id == "energy_connected_capacitor_insert_dielectric":
        return (
            ("still connected" in lower_question or "connected to the voltage source" in lower_question or "connected to the source" in lower_question)
            and "dielectric" in lower_question
        )
    if formula.id == "capacitance_parallel_plate_distance_doubled":
        return "distance" in lower_question and ("doubled" in lower_question or "doubles" in lower_question)
    if formula.id == "voltage_disconnected_capacitor_distance_doubled":
        return (
            "disconnected" in lower_question
            and "distance" in lower_question
            and ("doubled" in lower_question or "doubles" in lower_question)
        )
    if formula.id == "voltage_connected_capacitor_distance_changed":
        return (
            ("still connected" in lower_question or "connected to the source" in lower_question)
            and ("moved" in lower_question or "distance" in lower_question)
            and ("doubled" in lower_question or "doubles" in lower_question)
        )
    if formula.id == "charge_parallel_plate_circular_air_capacitor":
        return (
            ("circular plates" in lower_question or "radius" in lower_question)
            and "distance between the plates" in lower_question
            and ("potential difference" in lower_question or "voltage" in lower_question)
        )
    if formula.id == "turn_density_from_turns_length":
        return "turn density" in lower_question or "turns per" in lower_question
    if formula.id == "inductance_from_energy_current":
        return "inductance" in lower_question and "energy" in lower_question and "current" in lower_question
    if formula.id == "induced_emf_from_inductance_current_change":
        return (
            ("induced electromotive force" in lower_question or "emf" in lower_question)
            and ("current increases" in lower_question or "current decreases" in lower_question)
        )
    if formula.id == "inductance_from_emf_current_change":
        return "induced electromotive force" in lower_question or "emf" in lower_question
    if formula.id == "induced_emf_from_flux_change":
        return (
            ("induced electromotive force" in lower_question or "emf" in lower_question)
            and "magnetic flux" in lower_question
        )
    if formula.id == "magnetic_flux_from_field_area":
        return "magnetic flux" in lower_question and (
            "magnetic field" in lower_question or "flux density" in lower_question
        )
    if formula.id == "magnetic_flux_solenoid_from_turn_density_current_area":
        return "magnetic flux" in lower_question and "turn density" in lower_question
    if formula.id == "magnetic_field_solenoid_from_turns_length_current":
        return "magnetic field" in lower_question and "solenoid" in lower_question and "turns" in lower_question
    if formula.id == "magnetic_flux_solenoid_from_turns_length_current_area":
        return "magnetic flux" in lower_question and "solenoid" in lower_question and "turns" in lower_question
    if formula.id == "flux_linkage_from_turns_flux":
        return "flux linkage" in lower_question
    if formula.id == "magnetic_energy_density_from_field":
        return "energy density" in lower_question and "magnetic field" in lower_question
    if formula.id == "magnetic_energy_from_solenoid_geometry":
        return (
            ("magnetic energy" in lower_question or "magnetic field energy" in lower_question)
            and "solenoid" in lower_question
        )
    if formula.id == "lc_natural_angular_frequency":
        return "angular frequency" in lower_question and "lc" in lower_question
    if formula.id == "lc_natural_period":
        return "period" in lower_question and "lc" in lower_question
    if formula.id == "period_from_frequency":
        return "period" in lower_question and "frequency" in lower_question
    if formula.id == "frequency_from_period":
        return "frequency" in lower_question and "period" in lower_question
    if formula.id == "inductive_reactance":
        return "inductive reactance" in lower_question
    if formula.id == "capacitive_reactance":
        return "capacitive reactance" in lower_question
    if formula.id == "series_rlc_impedance":
        return "rlc" in lower_question and "impedance" in lower_question
    if formula.id == "current_from_voltage_impedance":
        return "impedance" in lower_question and "current" in lower_question
    if formula.id == "impedance_from_voltage_current":
        return "impedance" in lower_question and "voltage" in lower_question and "current" in lower_question
    if formula.id == "ac_power_from_voltage_impedance_resistance":
        return (
            "power" in lower_question
            and ("impedance" in lower_question or " z =" in lower_question)
            and ("resistance" in lower_question or " r =" in lower_question)
        )
    if formula.id == "power_factor_from_resistance_impedance":
        return "power factor" in lower_question
    return True
