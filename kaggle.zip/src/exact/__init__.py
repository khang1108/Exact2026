"""EXACT application package."""
